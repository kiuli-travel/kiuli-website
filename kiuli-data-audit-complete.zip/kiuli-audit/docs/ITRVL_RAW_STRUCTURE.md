# iTrvl Raw Scraper Output Structure

This is what Phase 2 (itrvl_scraper.cjs) produces:

## Top Level
- welcomeHero (s3Key for main image)
- name (itinerary title)
- itineraryDates (date range string)
- travelers (traveler count string)
- nights (number)
- accommodations (array of property names)

## Segments Array (flat, 28-35 per itinerary)

### type: "stay"
- title (property name)
- description (1000+ characters)
- images (3-12 per segment)
- clientIncludeExclude (inclusions text)
- nights (1-4)
- location (city/area)
- country

### type: "flight"
- title (airline and route)
- fromPoint
- toPoint
- departureTime
- arrivalTime

### type: "road"
- description (usually brief)
- images (sometimes)

### type: "service"
- title (activity name)
- description

## NOT in iTrvl data
- Investment Level (price range)
- FAQ section
- Structured days[] array
- blockType discriminators
