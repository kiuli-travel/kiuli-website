"use client"

import { useState, useCallback } from "react"
import EditorialUnit from "@/components/editorial-unit"

interface FieldState {
  enhancedValue: string
  isReviewed: boolean
  isEnhancing: boolean
}

const DEMO_FIELDS = [
  {
    fieldLabel: "Title",
    itrvlValue: "Family-Fun in Kenya",
    initialEnhanced: "",
    initialReviewed: false,
    multiline: false,
  },
  {
    fieldLabel: "Meta Description",
    itrvlValue:
      "Experience a 7-night luxury safari through Kenya. Exclusive lodges, expert guides, and unforgettable wildlife encounters. Inquire with Kiuli today.",
    initialEnhanced:
      "Seven nights of extraordinary encounters across Kenya\u2019s most iconic wilderness \u2014 Giraffe Manor, Lewa House, and the Masai Mara. Crafted exclusively for families who travel with intention.",
    initialReviewed: false,
    multiline: true,
  },
  {
    fieldLabel: "Meta Title",
    itrvlValue: "Family-Fun in Kenya | 7-Night Luxury Safari",
    initialEnhanced:
      "Kenya Family Safari: Giraffe Manor, Lewa & the Masai Mara | Kiuli",
    initialReviewed: true,
    multiline: false,
  },
] as const

export default function DemoPage() {
  const [fields, setFields] = useState<FieldState[]>(
    DEMO_FIELDS.map((f) => ({
      enhancedValue: f.initialEnhanced,
      isReviewed: f.initialReviewed,
      isEnhancing: false,
    }))
  )

  const updateField = useCallback(
    (index: number, patch: Partial<FieldState>) => {
      setFields((prev) =>
        prev.map((f, i) => (i === index ? { ...f, ...patch } : f))
      )
    },
    []
  )

  const handleEnhance = useCallback(
    async (index: number) => {
      updateField(index, { isEnhancing: true })
      await new Promise((resolve) => setTimeout(resolve, 1800))
      updateField(index, {
        isEnhancing: false,
        enhancedValue:
          "AI-enhanced version of: " + DEMO_FIELDS[index].itrvlValue,
      })
    },
    [updateField]
  )

  return (
    <main className="min-h-screen" style={{ background: "#F5F3EB" }}>
      <div className="mx-auto max-w-3xl px-6 py-10">
        {/* Header */}
        <header className="mb-8">
          <h1
            className="font-medium text-balance"
            style={{ fontSize: 18, color: "#404040" }}
          >
            {"Kiuli Admin \u2014 EditorialUnit (Dense)"}
          </h1>
        </header>

        {/* Grouped section */}
        <section>
          <span
            className="block uppercase font-medium"
            style={{
              fontSize: 11,
              letterSpacing: "0.08em",
              color: "#888",
              marginBottom: 8,
            }}
          >
            Core Fields
          </span>

          <div className="flex flex-col" style={{ gap: 8 }}>
            {DEMO_FIELDS.map((demo, i) => (
              <EditorialUnit
                key={demo.fieldLabel}
                fieldLabel={demo.fieldLabel}
                itrvlValue={demo.itrvlValue}
                enhancedValue={fields[i].enhancedValue}
                isReviewed={fields[i].isReviewed}
                multiline={demo.multiline}
                isEnhancing={fields[i].isEnhancing}
                onEnhancedChange={(value) =>
                  updateField(i, { enhancedValue: value })
                }
                onReviewedChange={(checked) =>
                  updateField(i, { isReviewed: checked })
                }
                onEnhance={() => handleEnhance(i)}
              />
            ))}
          </div>
        </section>
      </div>
    </main>
  )
}
