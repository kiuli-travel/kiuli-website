"use client"

import ItineraryEditorLayout from "@/components/itinerary-editor-layout"
import EditorHeader from "@/components/editor-header"
import EditorSidebar from "@/components/editor-sidebar"
import {
  BlockersPanel,
  HeroPanel,
  CoreFieldsAccordion,
  DaysAccordion,
  InvestmentAccordion,
  FAQAccordion,
  SEOAccordion,
} from "@/components/editor-sections"

export default function Page() {
  const progressPercent = 19

  return (
    <ItineraryEditorLayout
      progressPercent={progressPercent}
      header={<EditorHeader />}
      sidebar={<EditorSidebar />}
      mainContent={
        <>
          <BlockersPanel />
          <HeroPanel />
          <CoreFieldsAccordion />
          <DaysAccordion />
          <InvestmentAccordion />
          <FAQAccordion />
          <SEOAccordion />
        </>
      }
    />
  )
}
