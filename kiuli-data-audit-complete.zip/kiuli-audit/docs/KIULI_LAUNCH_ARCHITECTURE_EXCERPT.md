# KIULI Launch Architecture — Data Contract Excerpt

## CRITICAL SECTION: Data Contract (from Section 1.3)

```typescript
interface Itinerary {
  // Identity
  id: string;
  slug: string;
  title: string;

  // SEO
  metaTitle: string;
  metaDescription: string;

  // Hero
  heroImage: Media;
  heroImageLocked: boolean;

  // Overview
  overview: {
    summary: RichText;
    nights: number;
    countries: { country: string }[];
    highlights: { highlight: string }[];
  };

  // Investment
  investmentLevel: {
    fromPrice: number;
    toPrice?: number;
    currency: string;
    includes: RichText;
  };

  // Journey (structured days)
  days: Day[];

  // FAQ
  faqItems: FAQItem[];

  // Schema
  schema: object; // Product JSON-LD

  // Relationships
  destinations: Destination[];
  tripTypes: TripType[];

  // Status
  _status: 'draft' | 'published';
}

interface Day {
  dayNumber: number;
  date: string;
  title: string;
  location: string;
  segments: (Stay | Activity | Transfer)[];
}

interface Stay {
  blockType: 'stay';
  accommodationName: string;
  description: RichText;
  images: Media[];
  nights: number;
  location: string;
  country: string;
  inclusions: RichText;
}

interface Activity {
  blockType: 'activity';
  title: string;
  description: RichText;
  images: Media[];
}

interface Transfer {
  blockType: 'transfer';
  type: 'flight' | 'road' | 'boat';
  title: string;
  from: string;
  to: string;
  description: RichText;
}

interface FAQItem {
  question: string;
  answer: RichText;
}

interface Media {
  id: string;
  filename: string;
  alt: string;
  caption?: string;
  width: number;
  height: number;
  imgixUrl: string; // https://kiuli.imgix.net/media/{filename}
}
```

## CRITICAL SECTION: Page Sections (from Section 1.3)

| # | Section | Purpose | Data Source |
|---|---------|---------|-------------|
| 1 | Hero | Stop scroll, create desire | heroImage, title, overview |
| 2 | Trip Overview Bar | Establish credibility | nights, countries, highlights |
| 3 | Why Kiuli | Differentiate | Static content |
| 4 | Journey Narrative | Build value (longest section) | days[] array |
| 5 | Investment Level | Qualification gate | investmentLevel object |
| 6 | FAQ | Address objections, SEO | faqItems[] array |
| 7 | Related Itineraries | Cross-sell | Payload query |
| 8 | Final CTA | Convert | Static + form |

## CRITICAL PRINCIPLE

> The front-end does **zero data transformation**. Payload CMS stores data in the exact shape the front-end needs. The scraper and Content Agent handle all transformation before ingestion.
