"use client"

import { useState } from "react"
import {
  SectionStatusBadge,
  AccordionHeader,
} from "@/components/ui/kiuli-accordion"

const badgeExamples = [
  { reviewed: 0, total: 7, label: "0/7 reviewed" },
  { reviewed: 2, total: 7, label: "2/7 reviewed" },
  { reviewed: 7, total: 7, label: "7/7 reviewed" },
  { reviewed: 0, total: 45, label: "0/45 reviewed" },
]

const initialHeaders = [
  {
    id: "core",
    label: "Core Fields",
    reviewed: 2,
    total: 7,
    isOpen: false,
  },
  {
    id: "days",
    label: "Days — 4 days",
    reviewed: 0,
    total: 45,
    isOpen: true,
  },
  {
    id: "investment",
    label: "Investment Level",
    reviewed: 1,
    total: 1,
    isOpen: false,
  },
  {
    id: "faq",
    label: "FAQ",
    reviewed: 0,
    total: 7,
    isOpen: false,
    rightContent: (
      <span
        className="text-xs text-[#999]"
        style={{ fontFamily: "Inter, sans-serif" }}
      >
        7 questions
      </span>
    ),
  },
]

export default function Page() {
  const [headers, setHeaders] = useState(initialHeaders)

  const toggle = (id: string) => {
    setHeaders((prev) =>
      prev.map((h) => (h.id === id ? { ...h, isOpen: !h.isOpen } : h))
    )
  }

  return (
    <main
      className="min-h-screen px-6 py-12 md:px-12"
      style={{ backgroundColor: "#F5F3EB" }}
    >
      <div className="mx-auto max-w-2xl">
        {/* Page title */}
        <h1
          className="text-xl font-bold text-[#404040] mb-10"
          style={{ fontFamily: "Inter, sans-serif" }}
        >
          Kiuli Admin — Utility Components
        </h1>

        {/* ── Section 1: SectionStatusBadge ───────────────────── */}
        <section className="mb-12">
          <h2
            className="text-sm font-semibold tracking-wide uppercase text-[#486A6A] mb-5"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            SectionStatusBadge
          </h2>

          <div className="flex flex-wrap gap-6">
            {badgeExamples.map((ex) => (
              <div key={ex.label} className="flex flex-col items-start gap-1.5">
                <span
                  className="text-xs text-[#999]"
                  style={{ fontFamily: "Inter, sans-serif" }}
                >
                  {ex.label}
                </span>
                <SectionStatusBadge reviewed={ex.reviewed} total={ex.total} />
              </div>
            ))}
          </div>
        </section>

        {/* ── Section 2: AccordionHeader ──────────────────────── */}
        <section>
          <h2
            className="text-sm font-semibold tracking-wide uppercase text-[#486A6A] mb-5"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            {"AccordionHeader — All States"}
          </h2>

          <div className="flex flex-col gap-2">
            {headers.map((h) => (
              <AccordionHeader
                key={h.id}
                label={h.label}
                isOpen={h.isOpen}
                onToggle={() => toggle(h.id)}
                reviewed={h.reviewed}
                total={h.total}
                rightContent={h.rightContent}
              />
            ))}
          </div>
        </section>
      </div>
    </main>
  )
}
