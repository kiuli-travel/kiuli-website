"use client"

import { useState, useCallback } from "react"
import BlockersPanel, { type Blocker } from "@/components/blockers-panel"

function ScenarioLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="font-sans text-[13px] font-semibold text-[#404040] mb-2 uppercase tracking-wide">
      {children}
    </p>
  )
}

function Scenario1() {
  const blockers: Blocker[] = [
    {
      id: "1",
      message: "No trip type selected — required for search and filtering",
      onFix: () => console.log("Fix: trip type"),
    },
    {
      id: "2",
      message: "Title has not been reviewed",
      onFix: () => console.log("Fix: title review"),
    },
    {
      id: "3",
      message: "Investment level not configured",
      onFix: () => console.log("Fix: investment level"),
    },
  ]

  return (
    <div>
      <ScenarioLabel>Scenario 1 — 3 blockers</ScenarioLabel>
      <BlockersPanel blockers={blockers} />
    </div>
  )
}

function Scenario2() {
  const blockers: Blocker[] = [
    {
      id: "1",
      message: "No hero image selected",
      onFix: () => console.log("Fix: hero image"),
    },
  ]

  return (
    <div>
      <ScenarioLabel>Scenario 2 — 1 blocker</ScenarioLabel>
      <BlockersPanel blockers={blockers} />
    </div>
  )
}

function Scenario3() {
  const [blockers, setBlockers] = useState<Blocker[]>([
    {
      id: "a",
      message: "Cover photo is missing alt text",
      onFix: () => console.log("Fix: alt text"),
    },
    {
      id: "b",
      message: "Destination region not set",
      onFix: () => console.log("Fix: destination"),
    },
  ])

  const resolveBlocker = useCallback((id: string) => {
    setBlockers((prev) => prev.filter((b) => b.id !== id))
  }, [])

  return (
    <div>
      <ScenarioLabel>Scenario 3 — Interactive: resolve to zero</ScenarioLabel>
      <BlockersPanel blockers={blockers} />
      {blockers.length > 0 && (
        <div className="mt-3 flex gap-2">
          {blockers.map((b) => (
            <button
              key={b.id}
              onClick={() => resolveBlocker(b.id)}
              className="font-sans text-[12px] font-medium px-3 py-1.5 rounded-md bg-[#486A6A] text-white hover:bg-[#3a5858] transition-colors cursor-pointer"
              type="button"
            >
              {"Resolve: "}{b.message.split(" ").slice(0, 3).join(" ")}{"..."}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

export default function Page() {
  return (
    <main className="min-h-screen" style={{ background: "#F5F3EB" }}>
      <div className="mx-auto max-w-2xl px-6 py-12">
        <h1 className="font-sans text-[22px] font-bold text-[#404040] mb-1">
          Kiuli Admin — BlockersPanel
        </h1>
        <p className="font-sans text-[13px] text-[#404040]/60 mb-10">
          Component demo showing all panel states
        </p>

        <div className="flex flex-col gap-10">
          <Scenario1 />
          <Scenario2 />
          <Scenario3 />
        </div>
      </div>
    </main>
  )
}
