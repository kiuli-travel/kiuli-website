"use client"

import { useState, useCallback } from "react"
import DayAccordion from "@/components/day-accordion"

interface DayState {
  dayNumber: number
  dayTitleItrvl: string
  dayTitleEnhanced: string
  dayTitleReviewed: boolean
  segments: {
    id: string
    type: "transfer" | "stay" | "activity"
    name: string
    isReviewed: boolean
    hasEnhancedContent: boolean
  }[]
  isOpen: boolean
  isDayTitleEnhancing: boolean
  isEnhancingAll: boolean
}

const INITIAL_DAYS: DayState[] = [
  {
    dayNumber: 1,
    dayTitleItrvl: "Arrival in Nairobi",
    dayTitleEnhanced: "",
    dayTitleReviewed: false,
    segments: [
      { id: "1", type: "transfer", name: "Nairobi → Giraffe Manor", isReviewed: false, hasEnhancedContent: false },
      { id: "2", type: "stay", name: "Giraffe Manor", isReviewed: false, hasEnhancedContent: true },
      { id: "3", type: "transfer", name: "Transit Point via Jomo Kenyatta Airport", isReviewed: false, hasEnhancedContent: false },
    ],
    isOpen: true,
    isDayTitleEnhancing: false,
    isEnhancingAll: false,
  },
  {
    dayNumber: 2,
    dayTitleItrvl: "Fly to Lewa Conservancy",
    dayTitleEnhanced: "Into the Northern Frontier",
    dayTitleReviewed: true,
    segments: [
      { id: "4", type: "transfer", name: "Wilson Airport (WIL)", isReviewed: true, hasEnhancedContent: true },
      { id: "5", type: "stay", name: "Lewa House", isReviewed: false, hasEnhancedContent: false },
      { id: "6", type: "activity", name: "Lewa Wildlife Conservancy", isReviewed: false, hasEnhancedContent: true },
    ],
    isOpen: false,
    isDayTitleEnhancing: false,
    isEnhancingAll: false,
  },
]

export default function DayAccordionDemoPage() {
  const [days, setDays] = useState<DayState[]>(INITIAL_DAYS)

  const updateDay = useCallback((dayNumber: number, updater: (d: DayState) => DayState) => {
    setDays((prev) => prev.map((d) => (d.dayNumber === dayNumber ? updater(d) : d)))
  }, [])

  const handleToggle = useCallback(
    (dayNumber: number) => {
      updateDay(dayNumber, (d) => ({ ...d, isOpen: !d.isOpen }))
    },
    [updateDay]
  )

  const handleDayTitleChange = useCallback(
    (dayNumber: number, value: string) => {
      updateDay(dayNumber, (d) => ({ ...d, dayTitleEnhanced: value }))
    },
    [updateDay]
  )

  const handleDayTitleEnhance = useCallback(
    async (dayNumber: number) => {
      updateDay(dayNumber, (d) => ({ ...d, isDayTitleEnhancing: true }))
      await new Promise((r) => setTimeout(r, 1200))
      updateDay(dayNumber, (d) => ({
        ...d,
        isDayTitleEnhancing: false,
        dayTitleEnhanced:
          d.dayNumber === 1
            ? "A Grand Arrival in the Heart of Nairobi"
            : "Soaring Into the Northern Frontier",
      }))
    },
    [updateDay]
  )

  const handleDayTitleReviewedChange = useCallback(
    (dayNumber: number, checked: boolean) => {
      updateDay(dayNumber, (d) => ({ ...d, dayTitleReviewed: checked }))
    },
    [updateDay]
  )

  const handleEnhanceAll = useCallback(
    async (dayNumber: number) => {
      updateDay(dayNumber, (d) => ({ ...d, isEnhancingAll: true }))
      await new Promise((r) => setTimeout(r, 2000))
      updateDay(dayNumber, (d) => ({
        ...d,
        isEnhancingAll: false,
        segments: d.segments.map((s) => ({ ...s, hasEnhancedContent: true })),
      }))
    },
    [updateDay]
  )

  const handleMarkAllReviewed = useCallback(
    (dayNumber: number) => {
      updateDay(dayNumber, (d) => ({
        ...d,
        dayTitleReviewed: true,
        segments: d.segments.map((s) => ({ ...s, isReviewed: true })),
      }))
    },
    [updateDay]
  )

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#F5F3EB",
        fontFamily: "inherit",
      }}
    >
      {/* Page header */}
      <div
        style={{
          height: 64,
          background: "white",
          borderBottom: "1px solid #DADADA",
          display: "flex",
          alignItems: "center",
          padding: "0 24px",
          position: "sticky",
          top: 0,
          zIndex: 20,
        }}
      >
        <span
          style={{
            fontWeight: 700,
            fontSize: 16,
            color: "#486A6A",
            letterSpacing: "-0.01em",
          }}
        >
          Kiuli Admin
        </span>
        <span
          style={{
            fontWeight: 400,
            fontSize: 14,
            color: "#888",
            marginLeft: 12,
          }}
        >
          {"— DayAccordion Component"}
        </span>
      </div>

      {/* Content */}
      <div
        style={{
          maxWidth: 800,
          margin: "0 auto",
          padding: "24px 16px 64px",
          display: "flex",
          flexDirection: "column",
          gap: 8,
        }}
      >
        {days.map((day) => (
          <DayAccordion
            key={day.dayNumber}
            dayNumber={day.dayNumber}
            dayTitleItrvl={day.dayTitleItrvl}
            dayTitleEnhanced={day.dayTitleEnhanced}
            dayTitleReviewed={day.dayTitleReviewed}
            segments={day.segments}
            isOpen={day.isOpen}
            onToggle={() => handleToggle(day.dayNumber)}
            onDayTitleChange={(v) => handleDayTitleChange(day.dayNumber, v)}
            onDayTitleEnhance={() => handleDayTitleEnhance(day.dayNumber)}
            onDayTitleReviewedChange={(c) =>
              handleDayTitleReviewedChange(day.dayNumber, c)
            }
            onEnhanceAll={() => handleEnhanceAll(day.dayNumber)}
            onMarkAllReviewed={() => handleMarkAllReviewed(day.dayNumber)}
            isDayTitleEnhancing={day.isDayTitleEnhancing}
            isEnhancingAll={day.isEnhancingAll}
          />
        ))}
      </div>
    </div>
  )
}
