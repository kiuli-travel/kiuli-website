"use client"

import { useState, useCallback } from "react"
import FAQAccordion from "@/components/faq-accordion"
import type { FAQItem } from "@/components/faq-card"

const initialItems: FAQItem[] = [
  {
    id: "faq-1",
    questionItrvl: "What is the best time to visit Kenya?",
    questionEnhanced: "When is the ideal time to visit Kenya for a safari?",
    answerItrvl:
      "The best time to visit Kenya is during the dry seasons: January-March and July-October.",
    answerEnhanced: "",
    isReviewed: false,
  },
  {
    id: "faq-2",
    questionItrvl: "Is this itinerary suitable for young children?",
    questionEnhanced: "",
    answerItrvl:
      "This itinerary is suitable for children aged 6 and above. Giraffe Manor welcomes children of all ages.",
    answerEnhanced:
      "This itinerary has been thoughtfully designed for families travelling with children from age 6. Giraffe Manor is one of the few iconic properties that genuinely welcomes younger guests \u2014 breakfast with the giraffes is as magical at six as it is at sixty.",
    isReviewed: true,
  },
  {
    id: "faq-3",
    questionItrvl: "What is included in the investment?",
    questionEnhanced: "",
    answerItrvl:
      "All accommodation, meals, drinks, game drives, park fees and inter-camp flights are included.",
    answerEnhanced: "",
    isReviewed: false,
  },
  {
    id: "faq-4",
    questionItrvl: "How do I begin planning my safari with Kiuli?",
    questionEnhanced: "",
    answerItrvl:
      "Contact us through our website enquiry form and a travel designer will be in touch within 24 hours.",
    answerEnhanced: "",
    isReviewed: false,
  },
]

let nextId = 5

export default function FAQDemoPage() {
  const [isOpen, setIsOpen] = useState(true)
  const [items, setItems] = useState<FAQItem[]>(initialItems)
  const [enhancingId, setEnhancingId] = useState<string | null>(null)
  const [isEnhancingAll, setIsEnhancingAll] = useState(false)

  const handleItemChange = useCallback(
    (id: string, field: keyof FAQItem, value: string | boolean) => {
      setItems((prev) =>
        prev.map((item) =>
          item.id === id ? { ...item, [field]: value } : item
        )
      )
    },
    []
  )

  const handleEnhanceAnswer = useCallback(async (id: string) => {
    setEnhancingId(id)
    // Simulate AI enhancement delay
    await new Promise((r) => setTimeout(r, 1200))
    setItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item
        if (item.answerEnhanced.trim()) return item
        return {
          ...item,
          answerEnhanced: `${item.answerItrvl} — enhanced with the distinctive Kiuli tone, weaving in personal detail and understated luxury.`,
        }
      })
    )
    setEnhancingId(null)
  }, [])

  const handleEnhanceAll = useCallback(async () => {
    setIsEnhancingAll(true)
    const unenhanced = items.filter((i) => !i.answerEnhanced.trim())
    for (const faq of unenhanced) {
      setEnhancingId(faq.id)
      await new Promise((r) => setTimeout(r, 800))
      setItems((prev) =>
        prev.map((item) => {
          if (item.id !== faq.id) return item
          if (item.answerEnhanced.trim()) return item
          return {
            ...item,
            answerEnhanced: `${item.answerItrvl} — enhanced with the distinctive Kiuli tone, weaving in personal detail and understated luxury.`,
          }
        })
      )
    }
    setEnhancingId(null)
    setIsEnhancingAll(false)
  }, [items])

  const handleAddItem = useCallback(() => {
    const newItem: FAQItem = {
      id: `faq-${nextId++}`,
      questionItrvl: "",
      questionEnhanced: "",
      answerItrvl: "",
      answerEnhanced: "",
      isReviewed: false,
    }
    setItems((prev) => [...prev, newItem])
  }, [])

  const handleDeleteItem = useCallback((id: string) => {
    setItems((prev) => prev.filter((item) => item.id !== id))
  }, [])

  const handleReorder = useCallback(
    (fromIndex: number, toIndex: number) => {
      setItems((prev) => {
        const next = [...prev]
        const [moved] = next.splice(fromIndex, 1)
        next.splice(toIndex, 0, moved)
        return next
      })
    },
    []
  )

  return (
    <main className="min-h-screen bg-kiuli-ivory">
      <div className="mx-auto max-w-3xl px-6 py-10">
        <h1 className="mb-6 text-lg font-semibold text-kiuli-charcoal">
          Kiuli Admin — FAQAccordion
        </h1>
        <FAQAccordion
          isOpen={isOpen}
          onToggle={() => setIsOpen((o) => !o)}
          items={items}
          onItemChange={handleItemChange}
          onEnhanceAnswer={handleEnhanceAnswer}
          onEnhanceAll={handleEnhanceAll}
          onAddItem={handleAddItem}
          onDeleteItem={handleDeleteItem}
          onReorder={handleReorder}
          enhancingId={enhancingId}
          isEnhancingAll={isEnhancingAll}
        />
      </div>
    </main>
  )
}
