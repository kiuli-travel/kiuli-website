"use client"

import { useState, useCallback } from "react"
import SegmentCard from "@/components/segment-card"

// Simulates an AI enhance call with a small delay
function simulateEnhance(): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, 800))
}

export default function DemoPage() {
  // ── Card 1: Transfer (red / unreviewed) ──
  const [transferDesc, setTransferDesc] = useState("")
  const [transferReviewed, setTransferReviewed] = useState(false)
  const [transferEnhancing, setTransferEnhancing] = useState(false)

  const handleTransferEnhance = useCallback(async () => {
    setTransferEnhancing(true)
    await simulateEnhance()
    setTransferDesc(
      "A smooth private transfer whisks you from the bustle of Nairobi city centre to the leafy Langata suburb — roughly twenty serene minutes before the iconic Giraffe Manor gates appear.",
    )
    setTransferEnhancing(false)
  }, [])

  // ── Card 2: Stay (amber / enhanced but not reviewed) ──
  const [stayDesc, setStayDesc] = useState(
    "Tucked into 12 private acres in Langata, Giraffe Manor is unlike anywhere else on earth — a 1930s Scottish manor house where Rothschild giraffe wander freely through the gardens and push their ancient, knowing faces through the breakfast room windows.",
  )
  const [stayTitle, setStayTitle] = useState("")
  const [stayInclusions, setStayInclusions] = useState("")
  const [stayReviewed, setStayReviewed] = useState(false)
  const [stayImagesReviewed, setStayImagesReviewed] = useState(false)
  const [stayDescEnhancing, setStayDescEnhancing] = useState(false)
  const [stayTitleEnhancing, setStayTitleEnhancing] = useState(false)
  const [stayIncEnhancing, setStayIncEnhancing] = useState(false)
  const [stayImages, setStayImages] = useState([
    { id: "1", url: "", alt: "Giraffe Manor exterior" },
    { id: "2", url: "", alt: "Giraffe Manor dining" },
    { id: "3", url: "", alt: "Giraffe Manor gardens" },
  ])

  // ── Card 3: Activity (green / reviewed) ──
  const [activityDesc, setActivityDesc] = useState(
    "Daily access to one of Africa\u2019s most celebrated wildlife corridors — the Masai Mara National Reserve, where the annual Great Migration passes and the Big Five roam year-round.",
  )
  const [activityTitle, setActivityTitle] = useState("Masai Mara National Reserve — Daily Access")
  const [activityReviewed, setActivityReviewed] = useState(true)
  const [activityImagesReviewed, setActivityImagesReviewed] = useState(false)
  const [actDescEnhancing, setActDescEnhancing] = useState(false)
  const [actTitleEnhancing, setActTitleEnhancing] = useState(false)

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#F5F3EB",
        padding: "40px 16px",
      }}
    >
      <div style={{ maxWidth: 720, margin: "0 auto" }}>
        {/* Page title */}
        <h1
          style={{
            fontSize: 18,
            fontWeight: 600,
            color: "#404040",
            marginBottom: 24,
            letterSpacing: "-0.01em",
          }}
        >
          Kiuli Admin — SegmentCard Component
        </h1>

        {/* Day label */}
        <div
          style={{
            fontSize: 11,
            textTransform: "uppercase",
            color: "#888",
            letterSpacing: "0.06em",
            marginBottom: 8,
            fontWeight: 500,
          }}
        >
          Day 1 — Nairobi to Giraffe Manor
        </div>

        {/* Cards */}
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {/* Transfer */}
          <SegmentCard
            type="transfer"
            segmentName="Nairobi → Giraffe Manor"
            descriptionItrvl="Private road transfer from Nairobi city centre to Giraffe Manor, approximately 20 minutes."
            descriptionEnhanced={transferDesc}
            onDescriptionChange={setTransferDesc}
            onDescriptionEnhance={handleTransferEnhance}
            isDescriptionEnhancing={transferEnhancing}
            isReviewed={transferReviewed}
            onReviewedChange={setTransferReviewed}
          />

          {/* Stay */}
          <SegmentCard
            type="stay"
            segmentName="Giraffe Manor"
            descriptionItrvl="Set within a 12-acre sanctuary in the suburb of Langata, Giraffe Manor is one of Nairobi's most iconic boutique hotels."
            descriptionEnhanced={stayDesc}
            onDescriptionChange={setStayDesc}
            onDescriptionEnhance={async () => {
              setStayDescEnhancing(true)
              await simulateEnhance()
              setStayDesc(
                "Tucked into 12 private acres in Langata, Giraffe Manor is unlike anywhere else on earth — a 1930s Scottish manor house where Rothschild giraffe wander freely through the gardens and push their ancient, knowing faces through the breakfast room windows.",
              )
              setStayDescEnhancing(false)
            }}
            isDescriptionEnhancing={stayDescEnhancing}
            titleItrvl="Giraffe Manor"
            titleEnhanced={stayTitle}
            onTitleChange={setStayTitle}
            onTitleEnhance={async () => {
              setStayTitleEnhancing(true)
              await simulateEnhance()
              setStayTitle("Giraffe Manor — Langata, Nairobi")
              setStayTitleEnhancing(false)
            }}
            isTitleEnhancing={stayTitleEnhancing}
            inclusionsItrvl="All meals, all drinks, giraffe feeding experiences, house vehicle game drives"
            inclusionsEnhanced={stayInclusions}
            onInclusionsChange={setStayInclusions}
            onInclusionsEnhance={async () => {
              setStayIncEnhancing(true)
              await simulateEnhance()
              setStayInclusions(
                "Full board including all meals, premium beverages, daily giraffe feeding experiences at sunrise and sunset, and guided game drives in the manor's private vehicles.",
              )
              setStayIncEnhancing(false)
            }}
            isInclusionsEnhancing={stayIncEnhancing}
            images={stayImages}
            imagesReviewed={stayImagesReviewed}
            onImagesReviewedChange={setStayImagesReviewed}
            onAddImage={() => {
              setStayImages((prev) => [
                ...prev,
                { id: `new-${Date.now()}`, url: "", alt: "New image" },
              ])
            }}
            onRemoveImage={(id) => {
              setStayImages((prev) => prev.filter((img) => img.id !== id))
            }}
            isReviewed={stayReviewed}
            onReviewedChange={setStayReviewed}
          />

          {/* Activity */}
          <SegmentCard
            type="activity"
            segmentName="Masai Mara Park Fees"
            descriptionItrvl="Daily conservancy and park fees for access to the Masai Mara National Reserve."
            descriptionEnhanced={activityDesc}
            onDescriptionChange={setActivityDesc}
            onDescriptionEnhance={async () => {
              setActDescEnhancing(true)
              await simulateEnhance()
              setActivityDesc(
                "Daily access to one of Africa\u2019s most celebrated wildlife corridors — the Masai Mara National Reserve, where the annual Great Migration passes and the Big Five roam year-round.",
              )
              setActDescEnhancing(false)
            }}
            isDescriptionEnhancing={actDescEnhancing}
            titleItrvl="Masai Mara Park Fees"
            titleEnhanced={activityTitle}
            onTitleChange={setActivityTitle}
            onTitleEnhance={async () => {
              setActTitleEnhancing(true)
              await simulateEnhance()
              setActivityTitle("Masai Mara National Reserve — Daily Access")
              setActTitleEnhancing(false)
            }}
            isTitleEnhancing={actTitleEnhancing}
            images={[]}
            imagesReviewed={activityImagesReviewed}
            onImagesReviewedChange={setActivityImagesReviewed}
            onAddImage={() => {}}
            onRemoveImage={() => {}}
            isReviewed={activityReviewed}
            onReviewedChange={setActivityReviewed}
          />
        </div>
      </div>
    </main>
  )
}
