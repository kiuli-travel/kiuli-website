"use client"

import { useState } from "react"
import { ChevronRight, Sparkles, RefreshCw, Save, Send } from "lucide-react"

export default function EditorHeader() {
  const [saving, setSaving] = useState(false)

  const handleSave = () => {
    setSaving(true)
    setTimeout(() => setSaving(false), 1500)
  }

  return (
    <header
      className="flex items-center justify-between px-4 lg:px-6"
      style={{
        height: 64,
        background: "#FFFFFF",
        borderBottom: "1px solid #DADADA",
      }}
    >
      {/* Left side: breadcrumb + badge + progress */}
      <div className="flex items-center gap-3 min-w-0">
        {/* Breadcrumb */}
        <nav className="hidden sm:flex items-center gap-1.5 text-sm min-w-0" aria-label="Breadcrumb">
          <span className="text-[#6B6B6B] whitespace-nowrap">Itineraries</span>
          <ChevronRight className="flex-shrink-0 text-[#DADADA]" size={14} />
          <span className="font-medium text-[#404040] truncate">Family-Fun in Kenya</span>
        </nav>
        {/* Mobile title */}
        <span className="sm:hidden font-medium text-sm text-[#404040] truncate">Family-Fun in Kenya</span>

        {/* DRAFT badge */}
        <span
          className="flex-shrink-0 inline-flex items-center rounded px-2 py-0.5 text-xs font-semibold uppercase tracking-wide"
          style={{
            background: "#FEF3C7",
            color: "#92400E",
          }}
        >
          Draft
        </span>

        {/* Progress bar — hidden on small screens */}
        <div className="hidden md:flex items-center gap-2 ml-2">
          <div
            className="rounded-full overflow-hidden"
            style={{ width: 120, height: 6, background: "#DADADA" }}
          >
            <div
              className="h-full rounded-full transition-all"
              style={{ width: `${(12 / 63) * 100}%`, background: "#486A6A" }}
            />
          </div>
          <span className="text-xs text-[#6B6B6B] whitespace-nowrap">12 of 63 reviewed</span>
        </div>
      </div>

      {/* Right side: actions */}
      <div className="flex items-center gap-2">
        <button
          className="hidden lg:inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors hover:bg-[#F5F3EB]"
          style={{ color: "#486A6A", border: "1px solid #DADADA" }}
        >
          <Sparkles size={14} />
          Enhance All
        </button>
        <button
          className="hidden lg:inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors hover:bg-[#F5F3EB]"
          style={{ color: "#6B6B6B", border: "1px solid #DADADA" }}
        >
          <RefreshCw size={14} />
          Rescrape
        </button>
        <button
          onClick={handleSave}
          disabled={saving}
          className="inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors hover:bg-[#F5F3EB] disabled:opacity-60"
          style={{ color: "#404040", border: "1px solid #DADADA" }}
        >
          <Save size={14} />
          {saving ? "Saving..." : "Save Draft"}
        </button>
        <button
          disabled
          className="inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold text-white disabled:opacity-40"
          style={{ background: "#486A6A" }}
        >
          <Send size={14} />
          Publish
        </button>
      </div>
    </header>
  )
}
