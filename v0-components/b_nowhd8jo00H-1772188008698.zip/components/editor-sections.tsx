"use client"

import { useState } from "react"
import {
  AlertTriangle,
  ChevronDown,
  ChevronRight,
  CheckCircle2,
  Circle,
  Image as ImageIcon,
  CalendarDays,
  DollarSign,
  HelpCircle,
  Search,
  Sparkles,
} from "lucide-react"

/* ── Helpers ─────────────────────────────── */

function SectionCard({
  children,
  className = "",
}: {
  children: React.ReactNode
  className?: string
}) {
  return (
    <div
      className={`rounded-lg ${className}`}
      style={{ background: "#FFFFFF", border: "1px solid #DADADA" }}
    >
      {children}
    </div>
  )
}

function StatusBadge({
  variant,
  children,
}: {
  variant: "red" | "amber" | "green" | "gray"
  children: React.ReactNode
}) {
  const styles: Record<string, { bg: string; color: string }> = {
    red: { bg: "#FEF2F2", color: "#DC2626" },
    amber: { bg: "#FEF3C7", color: "#92400E" },
    green: { bg: "#F0FDF4", color: "#16A34A" },
    gray: { bg: "#F3F4F6", color: "#6B6B6B" },
  }
  const s = styles[variant]
  return (
    <span
      className="inline-flex items-center rounded px-2 py-0.5 text-xs font-medium"
      style={{ background: s.bg, color: s.color }}
    >
      {children}
    </span>
  )
}

function AccordionSection({
  id,
  icon,
  title,
  badge,
  defaultOpen = false,
  children,
}: {
  id?: string
  icon: React.ReactNode
  title: string
  badge?: React.ReactNode
  defaultOpen?: boolean
  children: React.ReactNode
}) {
  const [open, setOpen] = useState(defaultOpen)

  return (
    <SectionCard>
      <button
        id={id}
        onClick={() => setOpen(!open)}
        className="flex items-center w-full px-4 py-3 gap-3 text-left transition-colors hover:bg-[#FAFAF8] rounded-lg"
        aria-expanded={open}
      >
        <span className="text-[#486A6A]">{icon}</span>
        <span className="flex-1 text-sm font-semibold text-[#404040]">{title}</span>
        {badge}
        {open ? (
          <ChevronDown size={16} className="text-[#6B6B6B]" />
        ) : (
          <ChevronRight size={16} className="text-[#6B6B6B]" />
        )}
      </button>
      {open && (
        <div className="px-4 pb-4">
          <div style={{ height: 1, background: "#DADADA", marginBottom: 16 }} />
          {children}
        </div>
      )}
    </SectionCard>
  )
}

/* ── Field Row (inside core fields) ──── */

function FieldRow({
  label,
  status,
  value,
  placeholder,
}: {
  label: string
  status: "red" | "amber" | "green"
  value?: string
  placeholder?: string
}) {
  const statusColors = {
    red: { dot: "#DC2626", bg: "#FEF2F2" },
    amber: { dot: "#F59E0B", bg: "#FEF3C7" },
    green: { dot: "#16A34A", bg: "#F0FDF4" },
  }
  const c = statusColors[status]

  return (
    <div className="flex items-start gap-3 py-3" style={{ borderBottom: "1px solid #F3F4F6" }}>
      <div className="flex items-center gap-2 min-w-[140px] flex-shrink-0 pt-0.5">
        <span className="block rounded-full flex-shrink-0" style={{ width: 8, height: 8, background: c.dot }} />
        <span className="text-sm font-medium text-[#404040]">{label}</span>
      </div>
      <div className="flex-1 min-w-0">
        {value ? (
          <div
            className="rounded-md px-3 py-2 text-sm text-[#404040]"
            style={{ background: c.bg }}
          >
            {value}
          </div>
        ) : (
          <div
            className="rounded-md px-3 py-2 text-sm"
            style={{ background: c.bg, color: "#9CA3AF" }}
          >
            {placeholder || "Not set"}
          </div>
        )}
      </div>
      {status === "green" && <CheckCircle2 size={16} className="text-emerald-600 mt-2.5 flex-shrink-0" />}
      {status === "amber" && (
        <button className="mt-2 flex-shrink-0 rounded px-2 py-0.5 text-xs font-medium text-amber-700 hover:bg-amber-50 transition-colors">
          Review
        </button>
      )}
      {status === "red" && (
        <button className="mt-2 flex-shrink-0 flex items-center gap-1 rounded px-2 py-0.5 text-xs font-medium text-[#486A6A] hover:bg-[#F5F3EB] transition-colors">
          <Sparkles size={12} />
          Enhance
        </button>
      )}
    </div>
  )
}

/* ═════════════════════════════════════════ */
/* ── SECTION EXPORTS                       */
/* ═════════════════════════════════════════ */

export function BlockersPanel() {
  return (
    <div
      id="blockers"
      className="rounded-lg px-4 py-3 flex flex-col gap-2"
      style={{ background: "#FEF2F2", border: "1px solid #FECACA" }}
    >
      <div className="flex items-center gap-2 mb-1">
        <AlertTriangle size={16} className="text-red-600" />
        <span className="text-sm font-semibold text-red-700">2 Blockers</span>
      </div>
      <div className="flex items-center gap-2 text-sm text-red-700">
        <Circle size={6} className="flex-shrink-0 fill-red-400 text-red-400" />
        No trip type selected
      </div>
      <div className="flex items-center gap-2 text-sm text-red-700">
        <Circle size={6} className="flex-shrink-0 fill-red-400 text-red-400" />
        Investment level not configured
      </div>
    </div>
  )
}

export function HeroPanel() {
  return (
    <SectionCard>
      <div id="hero" className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <ImageIcon size={16} className="text-[#486A6A]" />
            <span className="text-sm font-semibold text-[#404040]">Hero Image</span>
          </div>
          <StatusBadge variant="amber">Image set</StatusBadge>
        </div>
        <div
          className="rounded-md overflow-hidden flex items-center justify-center"
          style={{ height: 180, background: "#D2B48C" }}
        >
          <div className="text-center">
            <ImageIcon size={32} className="mx-auto text-white/60 mb-2" />
            <span className="text-sm font-medium text-white/80">family-fun-kenya-hero.jpg</span>
            <span className="block text-xs text-white/60 mt-1">1920 x 1080</span>
          </div>
        </div>
      </div>
    </SectionCard>
  )
}

export function CoreFieldsAccordion() {
  return (
    <AccordionSection
      id="core"
      icon={<Search size={16} />}
      title="Core Fields"
      badge={
        <span className="text-xs text-[#6B6B6B]">1/5 reviewed</span>
      }
      defaultOpen
    >
      <div className="flex flex-col">
        <FieldRow
          label="Title"
          status="red"
          placeholder="Not enhanced — click Enhance to generate"
        />
        <FieldRow
          label="Meta Title"
          status="green"
          value="Family-Fun Safari Adventure in Kenya | Kiuli Travel"
        />
        <FieldRow
          label="Meta Description"
          status="amber"
          value="Discover the best family-friendly safari experiences across Kenya's most iconic reserves. Kid-safe, expert-guided, unforgettable."
        />
        <FieldRow
          label="Trip Types"
          status="red"
          placeholder="No trip types selected"
        />
        <div className="pt-3 text-xs text-[#6B6B6B]">
          + 2 more fields (Answer Capsule, Focus Keyword)
        </div>
      </div>
    </AccordionSection>
  )
}

export function DaysAccordion() {
  return (
    <AccordionSection
      id="days"
      icon={<CalendarDays size={16} />}
      title="Days"
      badge={
        <div className="flex items-center gap-2">
          <StatusBadge variant="gray">4 Days</StatusBadge>
          <span className="text-xs text-[#6B6B6B]">0/49 reviewed</span>
        </div>
      }
    >
      <div className="flex flex-col gap-2">
        {[1, 2, 3, 4].map((day) => (
          <div
            key={day}
            className="flex items-center gap-3 rounded-md px-3 py-2.5 text-sm transition-colors hover:bg-[#F5F3EB]"
            style={{ border: "1px solid #F3F4F6" }}
          >
            <span className="font-semibold text-[#486A6A]">Day {day}</span>
            <span className="text-[#6B6B6B] truncate flex-1">
              {["Nairobi — Arrival & City Tour", "Amboseli National Park", "Masai Mara Game Reserve", "Lake Nakuru & Departure"][day - 1]}
            </span>
            <span className="text-xs text-[#DADADA]">0/{[12, 14, 13, 10][day - 1]}</span>
            <ChevronRight size={14} className="text-[#DADADA]" />
          </div>
        ))}
      </div>
    </AccordionSection>
  )
}

export function InvestmentAccordion() {
  return (
    <AccordionSection
      id="investment"
      icon={<DollarSign size={16} />}
      title="Investment"
      badge={<StatusBadge variant="red">Required</StatusBadge>}
    >
      <div className="text-sm text-[#6B6B6B] py-4 text-center">
        No investment levels configured yet.
        <br />
        <button className="mt-2 text-[#486A6A] font-medium hover:underline">+ Add investment level</button>
      </div>
    </AccordionSection>
  )
}

export function FAQAccordion() {
  return (
    <AccordionSection
      id="faq"
      icon={<HelpCircle size={16} />}
      title="FAQ"
      badge={<span className="text-xs text-[#6B6B6B]">1/7 reviewed</span>}
    >
      <div className="flex flex-col gap-2">
        {[
          { q: "Is this safari safe for young children?", reviewed: true },
          { q: "What is the best time of year for a family safari?", reviewed: false },
          { q: "Are vaccinations required for Kenya?", reviewed: false },
          { q: "What should we pack for the trip?", reviewed: false },
          { q: "Can we customize the itinerary?", reviewed: false },
          { q: "What wildlife will we likely see?", reviewed: false },
          { q: "Is travel insurance included?", reviewed: false },
        ].map((faq, i) => (
          <div
            key={i}
            className="flex items-center gap-3 rounded-md px-3 py-2.5 text-sm"
            style={{ border: "1px solid #F3F4F6" }}
          >
            {faq.reviewed ? (
              <CheckCircle2 size={15} className="text-emerald-600 flex-shrink-0" />
            ) : (
              <Circle size={15} className="text-[#DADADA] flex-shrink-0" />
            )}
            <span className="flex-1 text-[#404040]">{faq.q}</span>
          </div>
        ))}
      </div>
    </AccordionSection>
  )
}

export function SEOAccordion() {
  return (
    <AccordionSection
      id="seo"
      icon={<Search size={16} />}
      title="SEO & Metadata"
      badge={<span className="text-xs text-[#6B6B6B]">0/3 reviewed</span>}
    >
      <div className="flex flex-col gap-2">
        {["Canonical URL", "Open Graph Image", "Structured Data"].map((field) => (
          <div
            key={field}
            className="flex items-center gap-3 rounded-md px-3 py-2.5 text-sm"
            style={{ border: "1px solid #F3F4F6" }}
          >
            <Circle size={15} className="text-[#DADADA] flex-shrink-0" />
            <span className="text-[#404040]">{field}</span>
            <span className="ml-auto text-xs text-[#DADADA]">Not reviewed</span>
          </div>
        ))}
      </div>
    </AccordionSection>
  )
}
