"use client"

interface SectionStatusBadgeProps {
  current: number
  total: number
  isBlocker?: boolean
  blockerText?: string
}

export function SectionStatusBadge({
  current,
  total,
  isBlocker = false,
  blockerText = "Required",
}: SectionStatusBadgeProps) {
  if (isBlocker) {
    return (
      <span className="inline-flex items-center rounded-full bg-kiuli-red-bg px-2.5 py-0.5 text-[10px] font-medium text-kiuli-red">
        {blockerText}
      </span>
    )
  }

  const isComplete = current === total && total > 0
  const bgColor = isComplete
    ? "bg-kiuli-green-bg"
    : "bg-kiuli-amber-bg"
  const textColor = isComplete
    ? "text-kiuli-green"
    : "text-kiuli-amber"

  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-medium ${bgColor} ${textColor}`}
    >
      {current}/{total}
    </span>
  )
}
