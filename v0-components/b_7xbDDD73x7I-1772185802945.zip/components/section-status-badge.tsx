"use client"

interface SectionStatusBadgeProps {
  reviewed: number
  total: number
}

export function SectionStatusBadge({ reviewed, total }: SectionStatusBadgeProps) {
  const allReviewed = reviewed === total && total > 0
  const noneReviewed = reviewed === 0

  let bgColor = "bg-kiuli-amber-light"
  let textColor = "text-kiuli-amber"

  if (allReviewed) {
    bgColor = "bg-kiuli-green-light"
    textColor = "text-kiuli-green"
  } else if (noneReviewed) {
    bgColor = "bg-kiuli-red-light"
    textColor = "text-kiuli-red"
  }

  return (
    <span
      className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium ${bgColor} ${textColor}`}
    >
      {reviewed}/{total} reviewed
    </span>
  )
}
