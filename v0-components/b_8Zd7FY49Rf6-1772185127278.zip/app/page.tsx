"use client"

import { useState, useCallback } from "react"
import InvestmentAccordion from "@/components/investment-accordion/investment-accordion"

type InvestmentTier = "essential" | "classic" | "premium" | "ultra" | null

interface AccordionState {
  isOpen: boolean
  selectedTier: InvestmentTier
  calloutItrvl: string
  calloutEnhanced: string
  calloutReviewed: boolean
  inclusionsItrvl: string
  inclusionsEnhanced: string
  inclusionsReviewed: boolean
  investmentReviewed: boolean
  isCalloutEnhancing: boolean
  isInclusionsEnhancing: boolean
}

const INITIAL_STATE_1: AccordionState = {
  isOpen: true,
  selectedTier: null,
  calloutItrvl: "Price on application.",
  calloutEnhanced: "",
  calloutReviewed: false,
  inclusionsItrvl:
    "All accommodation, all meals, all drinks, inter-camp flights, game drives, laundry, park fees.",
  inclusionsEnhanced: "",
  inclusionsReviewed: false,
  investmentReviewed: false,
  isCalloutEnhancing: false,
  isInclusionsEnhancing: false,
}

const INITIAL_STATE_2: AccordionState = {
  isOpen: true,
  selectedTier: "premium",
  calloutItrvl: "Price on application.",
  calloutEnhanced:
    "An investment crafted for families who expect nothing less than extraordinary \u2014 from the iconic rooms of Giraffe Manor to the vast horizons of the Masai Mara.",
  calloutReviewed: true,
  inclusionsItrvl:
    "All accommodation, all meals, all drinks, inter-camp flights, game drives, laundry, park fees.",
  inclusionsEnhanced: "",
  inclusionsReviewed: false,
  investmentReviewed: false,
  isCalloutEnhancing: false,
  isInclusionsEnhancing: false,
}

function useAccordionState(initial: AccordionState) {
  const [state, setState] = useState<AccordionState>(initial)

  const update = useCallback(
    <K extends keyof AccordionState>(key: K, value: AccordionState[K]) => {
      setState((prev) => ({ ...prev, [key]: value }))
    },
    []
  )

  const simulateEnhance = useCallback(
    (field: "callout" | "inclusions") => async () => {
      const enhancingKey =
        field === "callout" ? "isCalloutEnhancing" : "isInclusionsEnhancing"
      const enhancedKey =
        field === "callout" ? "calloutEnhanced" : "inclusionsEnhanced"

      setState((prev) => ({ ...prev, [enhancingKey]: true }))
      await new Promise((resolve) => setTimeout(resolve, 1200))
      setState((prev) => ({
        ...prev,
        [enhancingKey]: false,
        [enhancedKey]:
          field === "callout"
            ? "An extraordinary journey awaits \u2014 tailored exclusively for the discerning traveler seeking unparalleled luxury and authentic African experiences."
            : "All luxury accommodation, gourmet meals and fine wines, private inter-camp charter flights, exclusive guided game drives, personal laundry service, and all conservation and park fees included.",
      }))
    },
    []
  )

  return { state, update, simulateEnhance }
}

export default function InvestmentAccordionDemo() {
  const accordion1 = useAccordionState(INITIAL_STATE_1)
  const accordion2 = useAccordionState(INITIAL_STATE_2)

  return (
    <main className="min-h-screen bg-kiuli-ivory">
      <div className="mx-auto max-w-2xl px-4 py-10">
        <h1 className="mb-1 text-[20px] font-semibold text-kiuli-charcoal">
          Kiuli Admin — InvestmentAccordion
        </h1>
        <p className="mb-8 text-[13px] text-[#888]">
          Investment level configuration for itinerary editorial interface.
        </p>

        {/* Instance 1: No tier selected (blocker state) */}
        <div className="mb-6">
          <p className="mb-2 text-[11px] font-medium uppercase tracking-wider text-[#888]">
            No tier selected (blocker state)
          </p>
          <InvestmentAccordion
            isOpen={accordion1.state.isOpen}
            onToggle={() =>
              accordion1.update("isOpen", !accordion1.state.isOpen)
            }
            selectedTier={accordion1.state.selectedTier}
            onTierChange={(tier) => accordion1.update("selectedTier", tier)}
            calloutItrvl={accordion1.state.calloutItrvl}
            calloutEnhanced={accordion1.state.calloutEnhanced}
            calloutReviewed={accordion1.state.calloutReviewed}
            onCalloutChange={(v) => accordion1.update("calloutEnhanced", v)}
            onCalloutEnhance={accordion1.simulateEnhance("callout")}
            onCalloutReviewedChange={(v) =>
              accordion1.update("calloutReviewed", v)
            }
            isCalloutEnhancing={accordion1.state.isCalloutEnhancing}
            inclusionsItrvl={accordion1.state.inclusionsItrvl}
            inclusionsEnhanced={accordion1.state.inclusionsEnhanced}
            inclusionsReviewed={accordion1.state.inclusionsReviewed}
            onInclusionsChange={(v) =>
              accordion1.update("inclusionsEnhanced", v)
            }
            onInclusionsEnhance={accordion1.simulateEnhance("inclusions")}
            onInclusionsReviewedChange={(v) =>
              accordion1.update("inclusionsReviewed", v)
            }
            isInclusionsEnhancing={accordion1.state.isInclusionsEnhancing}
            investmentReviewed={accordion1.state.investmentReviewed}
            onInvestmentReviewedChange={(v) =>
              accordion1.update("investmentReviewed", v)
            }
          />
        </div>

        {/* Instance 2: Tier selected, partially reviewed */}
        <div className="mb-6">
          <p className="mb-2 text-[11px] font-medium uppercase tracking-wider text-[#888]">
            Tier selected, partially reviewed
          </p>
          <InvestmentAccordion
            isOpen={accordion2.state.isOpen}
            onToggle={() =>
              accordion2.update("isOpen", !accordion2.state.isOpen)
            }
            selectedTier={accordion2.state.selectedTier}
            onTierChange={(tier) => accordion2.update("selectedTier", tier)}
            calloutItrvl={accordion2.state.calloutItrvl}
            calloutEnhanced={accordion2.state.calloutEnhanced}
            calloutReviewed={accordion2.state.calloutReviewed}
            onCalloutChange={(v) => accordion2.update("calloutEnhanced", v)}
            onCalloutEnhance={accordion2.simulateEnhance("callout")}
            onCalloutReviewedChange={(v) =>
              accordion2.update("calloutReviewed", v)
            }
            isCalloutEnhancing={accordion2.state.isCalloutEnhancing}
            inclusionsItrvl={accordion2.state.inclusionsItrvl}
            inclusionsEnhanced={accordion2.state.inclusionsEnhanced}
            inclusionsReviewed={accordion2.state.inclusionsReviewed}
            onInclusionsChange={(v) =>
              accordion2.update("inclusionsEnhanced", v)
            }
            onInclusionsEnhance={accordion2.simulateEnhance("inclusions")}
            onInclusionsReviewedChange={(v) =>
              accordion2.update("inclusionsReviewed", v)
            }
            isInclusionsEnhancing={accordion2.state.isInclusionsEnhancing}
            investmentReviewed={accordion2.state.investmentReviewed}
            onInvestmentReviewedChange={(v) =>
              accordion2.update("investmentReviewed", v)
            }
          />
        </div>
      </div>
    </main>
  )
}
