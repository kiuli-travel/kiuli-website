"use client"

import { useState, useEffect, useCallback } from "react"

interface ItineraryEditorHeaderProps {
  itineraryTitle: string
  status: "draft" | "published"
  totalReviewed: number
  totalItems: number
  canPublish: boolean
  lastAutoSaved?: Date | null
  onNavigateToItineraries: () => void
  onEnhanceAll: () => Promise<void>
  onRescrape: () => void
  onSave: () => Promise<void>
  onPublish: () => void
  isEnhancingAll?: boolean
  className?: string
}

export default function ItineraryEditorHeader({
  itineraryTitle,
  status,
  totalReviewed,
  totalItems,
  canPublish,
  lastAutoSaved,
  onNavigateToItineraries,
  onEnhanceAll,
  onRescrape,
  onSave,
  onPublish,
  isEnhancingAll = false,
  className = "",
}: ItineraryEditorHeaderProps) {
  const [saveState, setSaveState] = useState<"idle" | "saving" | "saved">("idle")
  const [showAutoSaved, setShowAutoSaved] = useState(!!lastAutoSaved)

  const progressPercent = totalItems > 0 ? (totalReviewed / totalItems) * 100 : 0
  const isComplete = totalReviewed === totalItems && totalItems > 0

  // Auto-saved indicator fade out
  useEffect(() => {
    if (lastAutoSaved) {
      setShowAutoSaved(true)
      const timer = setTimeout(() => setShowAutoSaved(false), 5000)
      return () => clearTimeout(timer)
    }
  }, [lastAutoSaved])

  const handleSave = useCallback(async () => {
    if (saveState !== "idle") return
    setSaveState("saving")
    try {
      await onSave()
      setSaveState("saved")
      setTimeout(() => setSaveState("idle"), 2000)
    } catch {
      setSaveState("idle")
    }
  }, [onSave, saveState])

  const formatAutoSavedTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    })
  }

  const saveButtonText =
    saveState === "saving" ? "Saving…" : saveState === "saved" ? "Saved ✓" : "Save Draft"

  return (
    <header
      className={`sticky top-0 z-50 flex h-16 items-center border-b bg-white px-6 ${className}`}
      style={{
        borderColor: "var(--color-gray)",
        boxShadow: "0 1px 4px rgba(0,0,0,0.06)",
      }}
    >
      {/* LEFT SECTION */}
      <div className="flex w-[280px] shrink-0 flex-col justify-center gap-0.5">
        <div className="flex items-center">
          <button
            onClick={onNavigateToItineraries}
            className="cursor-pointer text-xs font-normal transition-colors hover:underline"
            style={{ color: "var(--color-teal)" }}
          >
            Itineraries
          </button>
          <span
            className="mx-1.5 text-xs font-normal"
            style={{ color: "var(--color-gray)" }}
          >
            /
          </span>
          <span
            className="max-w-[180px] truncate text-xs font-medium"
            style={{ color: "var(--color-charcoal)" }}
            title={itineraryTitle}
          >
            {itineraryTitle}
          </span>

          {/* Auto-saved indicator */}
          {showAutoSaved && lastAutoSaved && (
            <span
              className="ml-3 text-[10px] font-normal transition-opacity duration-500"
              style={{ color: "var(--color-muted-text)" }}
            >
              Auto-saved {formatAutoSavedTime(lastAutoSaved)}
            </span>
          )}
        </div>

        {/* Status badge */}
        <div>
          {status === "draft" ? (
            <span
              className="inline-block rounded-full px-2 py-px text-[10px] font-semibold uppercase"
              style={{
                background: "var(--color-ivory)",
                border: "1px solid var(--color-gray)",
                color: "var(--color-muted-text)",
              }}
            >
              Draft
            </span>
          ) : (
            <span
              className="inline-block rounded-full px-2 py-px text-[10px] font-semibold uppercase"
              style={{
                background: "var(--color-green-light)",
                border: "1px solid var(--color-green-border)",
                color: "var(--color-green)",
              }}
            >
              Published
            </span>
          )}
        </div>
      </div>

      {/* CENTER SECTION */}
      <div className="flex flex-1 flex-col items-center justify-center px-8">
        <span
          className="mb-1 text-center text-[11px] font-normal"
          style={{ color: "var(--color-muted-text)" }}
        >
          {totalReviewed} of {totalItems} reviewed
        </span>
        <div
          className="h-1 w-full rounded-full"
          style={{ background: "var(--color-gray)" }}
        >
          <div
            className="h-1 rounded-full transition-all duration-300 ease-in-out"
            style={{
              width: `${progressPercent}%`,
              background: isComplete
                ? "var(--color-green)"
                : "var(--color-teal)",
            }}
          />
        </div>
      </div>

      {/* RIGHT SECTION */}
      <div className="flex w-[320px] shrink-0 items-center justify-end gap-2">
        {/* Enhance All */}
        <button
          onClick={onEnhanceAll}
          disabled={isEnhancingAll}
          className="cursor-pointer border-none bg-transparent text-xs font-medium transition-colors hover:underline disabled:cursor-wait disabled:opacity-60"
          style={{ color: "var(--color-clay)" }}
          onMouseEnter={(e) => {
            if (!isEnhancingAll)
              (e.currentTarget as HTMLButtonElement).style.color =
                "var(--color-clay-hover)"
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLButtonElement).style.color =
              "var(--color-clay)"
          }}
        >
          {isEnhancingAll ? "Enhancing…" : "✨ Enhance All"}
        </button>

        {/* Rescrape */}
        <button
          onClick={onRescrape}
          className="cursor-pointer border-none bg-transparent text-xs font-medium transition-colors hover:underline"
          style={{ color: "var(--color-muted-text)" }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLButtonElement).style.color =
              "var(--color-teal)"
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLButtonElement).style.color =
              "var(--color-muted-text)"
          }}
        >
          ↻ Rescrape
        </button>

        {/* Save Draft */}
        <button
          onClick={handleSave}
          disabled={saveState !== "idle"}
          className="h-[34px] cursor-pointer rounded-md bg-white px-4 text-xs font-medium transition-colors disabled:cursor-default"
          style={{
            border: "1px solid var(--color-gray)",
            color:
              saveState === "saved"
                ? "var(--color-green)"
                : "var(--color-charcoal)",
          }}
          onMouseEnter={(e) => {
            if (saveState === "idle") {
              ;(e.currentTarget as HTMLButtonElement).style.borderColor =
                "var(--color-teal)"
              ;(e.currentTarget as HTMLButtonElement).style.color =
                "var(--color-teal)"
            }
          }}
          onMouseLeave={(e) => {
            ;(e.currentTarget as HTMLButtonElement).style.borderColor =
              "var(--color-gray)"
            ;(e.currentTarget as HTMLButtonElement).style.color =
              saveState === "saved"
                ? "var(--color-green)"
                : "var(--color-charcoal)"
          }}
        >
          {saveButtonText}
        </button>

        {/* Divider */}
        <div
          className="mx-1 h-5 w-px self-center"
          style={{ background: "var(--color-gray)" }}
        />

        {/* Publish */}
        {status === "published" ? (
          <button
            disabled
            className="h-[34px] cursor-default rounded-md border-none bg-transparent px-4 text-xs font-semibold"
            style={{ color: "var(--color-green)" }}
          >
            Published ✓
          </button>
        ) : canPublish ? (
          <button
            onClick={onPublish}
            className="h-[34px] cursor-pointer rounded-md border-none px-4 text-xs font-semibold text-white transition-colors"
            style={{ background: "var(--color-teal)" }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLButtonElement).style.background =
                "var(--color-teal-hover)"
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLButtonElement).style.background =
                "var(--color-teal)"
            }}
          >
            Publish
          </button>
        ) : (
          <div className="group relative">
            <button
              disabled
              className="h-[34px] cursor-not-allowed rounded-md px-4 text-xs font-semibold"
              style={{
                background: "var(--color-ivory)",
                border: "1px solid var(--color-gray)",
                color: "var(--color-gray)",
              }}
            >
              Publish
            </button>
            <div className="pointer-events-none absolute top-full right-0 z-10 mt-1 whitespace-nowrap rounded-md bg-[var(--color-charcoal)] px-2.5 py-1.5 text-[11px] text-white opacity-0 shadow-md transition-opacity group-hover:opacity-100">
              Complete all review items to publish
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
