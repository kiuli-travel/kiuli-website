"use client"

import { useId } from "react"
import { ChevronRight } from "lucide-react"
import { SectionStatusBadge } from "./section-status-badge"
import { TierSelector } from "./tier-selector"
import { EditorialUnit } from "./editorial-unit"

type InvestmentTier = "essential" | "classic" | "premium" | "ultra" | null

interface InvestmentAccordionProps {
  isOpen: boolean
  onToggle: () => void

  // Tier
  selectedTier: InvestmentTier
  onTierChange: (tier: InvestmentTier) => void

  // Investment Callout
  calloutItrvl: string
  calloutEnhanced: string
  calloutReviewed: boolean
  onCalloutChange: (v: string) => void
  onCalloutEnhance: () => Promise<void>
  onCalloutReviewedChange: (v: boolean) => void
  isCalloutEnhancing?: boolean

  // What's Included
  inclusionsItrvl: string
  inclusionsEnhanced: string
  inclusionsReviewed: boolean
  onInclusionsChange: (v: string) => void
  onInclusionsEnhance: () => Promise<void>
  onInclusionsReviewedChange: (v: boolean) => void
  isInclusionsEnhancing?: boolean

  // Overall
  investmentReviewed: boolean
  onInvestmentReviewedChange: (v: boolean) => void

  className?: string
}

export default function InvestmentAccordion({
  isOpen,
  onToggle,
  selectedTier,
  onTierChange,
  calloutItrvl,
  calloutEnhanced,
  calloutReviewed,
  onCalloutChange,
  onCalloutEnhance,
  onCalloutReviewedChange,
  isCalloutEnhancing,
  inclusionsItrvl,
  inclusionsEnhanced,
  inclusionsReviewed,
  onInclusionsChange,
  onInclusionsEnhance,
  onInclusionsReviewedChange,
  isInclusionsEnhancing,
  investmentReviewed,
  onInvestmentReviewedChange,
  className = "",
}: InvestmentAccordionProps) {
  const id = useId()
  const isBlocker = selectedTier === null
  const reviewedCount = investmentReviewed ? 1 : 0

  return (
    <div className={className}>
      {/* Header */}
      <button
        type="button"
        onClick={onToggle}
        className={`flex h-[44px] w-full cursor-pointer items-center border border-kiuli-gray px-3 ${
          isOpen
            ? "rounded-t-[6px] rounded-b-none"
            : "rounded-[6px]"
        } bg-kiuli-white transition-colors hover:bg-[#FAFAFA]`}
      >
        <ChevronRight
          className={`mr-2 h-4 w-4 text-kiuli-teal transition-transform duration-200 ${
            isOpen ? "rotate-90" : ""
          }`}
        />
        <span className="text-[13px] font-medium text-kiuli-charcoal">
          Investment Level
        </span>
        <span className="ml-auto">
          <SectionStatusBadge
            current={reviewedCount}
            total={1}
            isBlocker={isBlocker}
            blockerText="Required"
          />
        </span>
      </button>

      {/* Content */}
      {isOpen && (
        <div className="rounded-b-[6px] border border-t-0 border-kiuli-gray bg-kiuli-white">
          {/* Section 1: Tier Selector */}
          <TierSelector
            selectedTier={selectedTier}
            onTierChange={onTierChange}
          />

          {/* Section 2: Investment Callout */}
          <EditorialUnit
            label="Investment Callout"
            helper="Short text shown to the prospect on the itinerary page. 1-2 sentences."
            itrvlValue={calloutItrvl}
            enhancedValue={calloutEnhanced}
            reviewed={calloutReviewed}
            onEnhancedChange={onCalloutChange}
            onEnhance={onCalloutEnhance}
            onReviewedChange={onCalloutReviewedChange}
            isEnhancing={isCalloutEnhancing}
            minHeight="56px"
          />

          {/* Section 3: What's Included */}
          <EditorialUnit
            label="What's Included"
            helper="List what is included in the investment. Displayed on the itinerary page."
            itrvlValue={inclusionsItrvl}
            enhancedValue={inclusionsEnhanced}
            reviewed={inclusionsReviewed}
            onEnhancedChange={onInclusionsChange}
            onEnhance={onInclusionsEnhance}
            onReviewedChange={onInclusionsReviewedChange}
            isEnhancing={isInclusionsEnhancing}
            minHeight="80px"
          />

          {/* Overall Reviewed Footer */}
          <div className="flex items-center justify-between border-t border-kiuli-gray px-3 py-2.5">
            <span className="text-[12px] text-[#666]">
              Mark investment section as complete
            </span>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id={`${id}-investment-reviewed`}
                checked={investmentReviewed}
                onChange={(e) => onInvestmentReviewedChange(e.target.checked)}
                className="h-3.5 w-3.5 rounded border-kiuli-gray accent-kiuli-teal"
              />
              <label
                htmlFor={`${id}-investment-reviewed`}
                className={`text-[12px] ${
                  investmentReviewed
                    ? "font-medium text-kiuli-green"
                    : "text-[#666]"
                }`}
              >
                Investment Reviewed
              </label>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
