"use client"

import { useState, useMemo } from "react"
import ItineraryEditorHeader from "@/components/itinerary-editor-header"

type DemoState = "in-progress" | "ready" | "published"

const STATES: { key: DemoState; label: string }[] = [
  { key: "in-progress", label: "In Progress (12/63)" },
  { key: "ready", label: "Ready to Publish (63/63)" },
  { key: "published", label: "Published" },
]

export default function Page() {
  const [activeState, setActiveState] = useState<DemoState>("in-progress")

  const headerProps = useMemo(() => {
    const base = {
      itineraryTitle: "Family-Fun in Kenya",
      onNavigateToItineraries: () => alert("Navigate to itineraries list"),
      onEnhanceAll: () =>
        new Promise<void>((resolve) => setTimeout(resolve, 1500)),
      onRescrape: () => alert("Rescrape triggered"),
      onSave: () => new Promise<void>((resolve) => setTimeout(resolve, 1000)),
      onPublish: () => alert("Published!"),
    }

    switch (activeState) {
      case "in-progress":
        return {
          ...base,
          status: "draft" as const,
          totalReviewed: 12,
          totalItems: 63,
          canPublish: false,
          lastAutoSaved: new Date(
            new Date().setHours(10, 34, 0, 0)
          ),
        }
      case "ready":
        return {
          ...base,
          status: "draft" as const,
          totalReviewed: 63,
          totalItems: 63,
          canPublish: true,
          lastAutoSaved: null,
        }
      case "published":
        return {
          ...base,
          status: "published" as const,
          totalReviewed: 63,
          totalItems: 63,
          canPublish: false,
          lastAutoSaved: null,
        }
    }
  }, [activeState])

  return (
    <div className="min-h-screen" style={{ background: "var(--color-ivory)" }}>
      {/* Sticky header */}
      <ItineraryEditorHeader {...headerProps} />

      {/* State switcher */}
      <div className="mx-auto max-w-3xl px-6 pt-8">
        <div className="mb-6 flex items-center gap-2">
          <span
            className="mr-2 text-xs font-medium uppercase tracking-wide"
            style={{ color: "var(--color-muted-text)" }}
          >
            Demo State
          </span>
          {STATES.map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setActiveState(key)}
              className="cursor-pointer rounded-md px-3 py-1.5 text-xs font-medium transition-colors"
              style={{
                background:
                  activeState === key ? "var(--color-teal)" : "white",
                color:
                  activeState === key ? "white" : "var(--color-charcoal)",
                border:
                  activeState === key
                    ? "1px solid var(--color-teal)"
                    : "1px solid var(--color-gray)",
              }}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Fake content blocks to show sticky behavior */}
        <div className="flex flex-col gap-4 pb-16">
          {Array.from({ length: 12 }).map((_, i) => (
            <div
              key={i}
              className="rounded-lg border bg-white p-6"
              style={{ borderColor: "var(--color-gray)" }}
            >
              <div className="mb-3 flex items-center gap-3">
                <div
                  className="h-3 rounded-full"
                  style={{
                    width: `${100 + (i % 3) * 40}px`,
                    background: "var(--color-gray)",
                  }}
                />
                <div
                  className="h-3 w-12 rounded-full"
                  style={{ background: "var(--color-ivory)" }}
                />
              </div>
              <div className="flex flex-col gap-2">
                <div
                  className="h-2.5 w-full rounded-full"
                  style={{ background: "var(--color-ivory)" }}
                />
                <div
                  className="h-2.5 rounded-full"
                  style={{
                    width: `${85 - (i % 4) * 10}%`,
                    background: "var(--color-ivory)",
                  }}
                />
                <div
                  className="h-2.5 rounded-full"
                  style={{
                    width: `${70 + (i % 3) * 8}%`,
                    background: "var(--color-ivory)",
                  }}
                />
              </div>
              {i % 2 === 0 && (
                <div
                  className="mt-4 h-24 w-full rounded-md"
                  style={{ background: "var(--color-ivory)" }}
                />
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
