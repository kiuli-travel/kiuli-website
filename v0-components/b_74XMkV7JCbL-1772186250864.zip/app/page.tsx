"use client"

import { useState } from "react"
import HeroPanel from "@/components/hero-panel"

export default function Page() {
  // Instance 1 — Image set, not reviewed
  const [img1, setImg1] = useState<string | null>("set")
  const [img1Locked, setImg1Locked] = useState(false)
  const [img1Reviewed, setImg1Reviewed] = useState(false)
  const [vid1Locked, setVid1Locked] = useState(false)
  const [vid1Reviewed, setVid1Reviewed] = useState(false)
  const [showVid1, setShowVid1] = useState(false)

  // Instance 2 — No image selected
  const [img2, setImg2] = useState<string | null>(null)
  const [img2Locked, setImg2Locked] = useState(false)
  const [img2Reviewed, setImg2Reviewed] = useState(false)
  const [vid2Locked, setVid2Locked] = useState(false)
  const [vid2Reviewed, setVid2Reviewed] = useState(false)
  const [showVid2, setShowVid2] = useState(false)

  return (
    <main
      className="min-h-screen px-4 py-10 font-sans sm:px-8"
      style={{ backgroundColor: "#F5F3EB" }}
    >
      <div className="mx-auto max-w-2xl">
        <h1
          className="mb-1 text-lg font-semibold"
          style={{ color: "#404040" }}
        >
          Kiuli Admin — HeroPanel
        </h1>
        <p className="mb-6 text-xs" style={{ color: "#888" }}>
          Two interactive demo instances below
        </p>

        <div className="flex flex-col gap-4">
          {/* Instance 1 */}
          <div>
            <p
              className="mb-1.5 text-[11px] font-medium uppercase tracking-wide"
              style={{ color: "#888" }}
            >
              Instance 1 — Image set, not reviewed
            </p>
            <HeroPanel
              heroImageUrl={img1}
              heroImageAlt="Giraffes mingling with guests at Giraffe Manor in Kenya during golden hour."
              isImageLocked={img1Locked}
              isImageReviewed={img1Reviewed}
              onSelectImage={() => setImg1("set")}
              onClearImage={() => setImg1(null)}
              onImageLockedChange={setImg1Locked}
              onImageReviewedChange={setImg1Reviewed}
              heroVideoUrl={null}
              heroVideoName=""
              isVideoLocked={vid1Locked}
              isVideoReviewed={vid1Reviewed}
              showHeroVideo={showVid1}
              onSelectVideo={() => {}}
              onVideoLockedChange={setVid1Locked}
              onVideoReviewedChange={setVid1Reviewed}
              onShowHeroVideoChange={setShowVid1}
            />
          </div>

          {/* Instance 2 */}
          <div>
            <p
              className="mb-1.5 text-[11px] font-medium uppercase tracking-wide"
              style={{ color: "#888" }}
            >
              Instance 2 — No image selected
            </p>
            <HeroPanel
              heroImageUrl={img2}
              heroImageAlt=""
              isImageLocked={img2Locked}
              isImageReviewed={img2Reviewed}
              onSelectImage={() => setImg2("set")}
              onClearImage={() => setImg2(null)}
              onImageLockedChange={setImg2Locked}
              onImageReviewedChange={setImg2Reviewed}
              heroVideoUrl={null}
              heroVideoName=""
              isVideoLocked={vid2Locked}
              isVideoReviewed={vid2Reviewed}
              showHeroVideo={showVid2}
              onSelectVideo={() => {}}
              onVideoLockedChange={setVid2Locked}
              onVideoReviewedChange={setVid2Reviewed}
              onShowHeroVideoChange={setShowVid2}
            />
          </div>
        </div>
      </div>
    </main>
  )
}
