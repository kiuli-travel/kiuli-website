# KIULI DATA CONTRACT AUDIT — Evidence Manifest

## Collection Date
2026-01-20

## Files Collected

### Payload Generated Types & Config
- [x] 00-payload-types-generated.ts (71,100 bytes) - Auto-generated TypeScript types from Payload
- [x] 00b-payload-config.ts (3,354 bytes) - Main Payload configuration

### Payload Collection Schemas
- [x] 01-itineraries-collection.ts (20,616 bytes) - Main itinerary collection with segments, etc.
- [x] 01b-image-statuses-collection.ts (3,017 bytes) - Image status tracking collection
- [x] 02-media-collection.ts (11,136 bytes) - Media collection with AI labeling fields
- [x] 03-itinerary-jobs-collection.ts (13,361 bytes) - Background job tracking collection

### Live Payload Data
- [ ] 04-itineraries-list.json - **FAILED**: Production API returned "You are not allowed to perform this action" with API key authentication
- [ ] 05-single-itinerary-full.json - **FAILED**: Same authentication issue
- [ ] 06-media-with-labels.json - **FAILED**: Same authentication issue
- [x] 04-itineraries-list.json.NOTE - Documents the API access failure

### Pipeline Processor Logic
- [x] 07-payload-ingester.cjs (6,821 bytes) - Phase 7: Creates Payload records from enhanced data
- [x] 08-content-enhancer.cjs (8,937 bytes) - Phase 4: AI enhancement of raw itinerary data
- [x] 09-schema-generator.cjs (7,652 bytes) - Phase 5: JSON-LD schema generation
- [x] 10-itrvl-scraper.cjs (11,376 bytes) - Phase 2: Scrapes ITRVL source
- [x] 11-media-rehoster.cjs (10,865 bytes) - Phase 3: Rehosts media to S3
- [x] 12-faq-formatter.cjs (5,858 bytes) - Phase 6: FAQ HTML generation

### Pipeline Outputs (from output/680dff493cf205005cf76e8f/)
- [x] pipeline-outputs/raw-itinerary.json (154,284 bytes) - Phase 2 output
- [x] pipeline-outputs/media-mapping.json (83,859 bytes) - Phase 3 output
- [ ] pipeline-outputs/enhanced-itinerary.json - **NOT FOUND**: Pipeline was never completed to Phase 4
- [ ] pipeline-outputs/schema.jsonld - **NOT FOUND**: Pipeline was never completed to Phase 5
- [ ] pipeline-outputs/faq.html - **NOT FOUND**: Pipeline was never completed to Phase 6

### Additional Components (Itinerary Admin UI)
- [x] itineraries-components/EnhanceAll.tsx (6,328 bytes)
- [x] itineraries-components/EnhanceButton.tsx (5,134 bytes)
- [x] itineraries-components/ImageStatusGrid.tsx (10,725 bytes)
- [x] itineraries-components/ItinerarySideNav.tsx (13,353 bytes)
- [x] itineraries-components/PublishChecklist.tsx (5,750 bytes)
- [x] itineraries-components/ReviewToggle.tsx (1,483 bytes)

### Shared Types
- [x] shared-types/media-component-types.ts (717 bytes)

### Documentation
- [x] docs/CLAUDE.md (4,301 bytes)
- [x] docs/KIULI_BACKEND_INVESTIGATION.md (13,811 bytes)
- [x] docs/KIULI_SCRAPER_DEEP_AUDIT.md (16,722 bytes)
- [x] docs/SCRAPER_DOCUMENTATION.md (14,812 bytes)
- [x] docs/V4_IMPLEMENTATION_REPORT.md (9,799 bytes)
- [ ] docs/KIULI_LAUNCH_ARCHITECTURE.md - **NOT FOUND**: File does not exist in repository
- [ ] docs/KIULI_DESIGN_PRODUCTION_GUIDE.md - **NOT FOUND**: File does not exist in repository

## Missing Evidence

### Critical Missing
1. **Live Payload Data**: Production API requires authentication. Tried both `Authorization: Bearer $PAYLOAD_API_KEY` and `X-API-Key: $PAYLOAD_API_KEY` headers - both returned 403 "You are not allowed to perform this action". The PAYLOAD_API_KEY exists in .env.local but doesn't grant API access.

2. **Later Pipeline Phase Outputs**: No enhanced-itinerary.json, schema.jsonld, or faq.html found in any output directory. Pipeline was never completed beyond Phase 3 (media rehoster). This confirms the CLAUDE.md failure history: "0 itineraries in production" and "Pipeline never completed full cycle".

3. **Design Documents**: KIULI_LAUNCH_ARCHITECTURE.md and KIULI_DESIGN_PRODUCTION_GUIDE.md referenced in task do not exist in the repository.

## Observations

### State of Data
1. **No itineraries in production confirmed**: Cannot query production API, and no complete pipeline outputs exist
2. **Pipeline incomplete**: 3 output directories exist but none have outputs beyond Phase 3
3. **Schema is comprehensive**: The Itineraries collection (01-itineraries-collection.ts) is 20KB with extensive field definitions
4. **Payload types generated**: The 71KB payload-types.ts file contains complete TypeScript interfaces for all collections
5. **Media collection has AI labeling**: Fields for labelingStatus, labelingError, sceneDescription, etc. are present

### Output Directories Found
- `output/680df8bb3cf205005cf76e57/` - Only raw-itinerary.json
- `output/680df9b0819f37005c255a1c/` - Only raw-itinerary.json
- `output/680dff493cf205005cf76e8f/` - raw-itinerary.json + media-mapping.json (most complete)

### Uncommitted Changes in Repository
Per git status at conversation start:
- Modified: src/migrations/index.ts
- Untracked: src/collections/Itineraries/components/ReviewToggle.tsx
- Untracked: src/migrations/20260120_add_reviewed_to_segments.ts
