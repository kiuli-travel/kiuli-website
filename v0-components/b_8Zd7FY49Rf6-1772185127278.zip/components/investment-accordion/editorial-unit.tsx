"use client"

import { useId } from "react"
import { Sparkles } from "lucide-react"

type ReviewedState = "unreviewed" | "enhanced" | "reviewed"

interface EditorialUnitProps {
  label: string
  helper: string
  itrvlValue: string
  enhancedValue: string
  reviewed: boolean
  onEnhancedChange: (v: string) => void
  onEnhance: () => Promise<void>
  onReviewedChange: (v: boolean) => void
  isEnhancing?: boolean
  minHeight?: string
}

function getReviewedState(
  enhancedValue: string,
  reviewed: boolean
): ReviewedState {
  if (reviewed) return "reviewed"
  if (enhancedValue.trim().length > 0) return "enhanced"
  return "unreviewed"
}

function getBorderColor(state: ReviewedState): string {
  switch (state) {
    case "reviewed":
      return "border-l-kiuli-green"
    case "enhanced":
      return "border-l-kiuli-amber"
    case "unreviewed":
      return "border-l-kiuli-red"
  }
}

export function EditorialUnit({
  label,
  helper,
  itrvlValue,
  enhancedValue,
  reviewed,
  onEnhancedChange,
  onEnhance,
  onReviewedChange,
  isEnhancing = false,
  minHeight = "56px",
}: EditorialUnitProps) {
  const id = useId()
  const state = getReviewedState(enhancedValue, reviewed)
  const borderColor = getBorderColor(state)

  return (
    <div className="border-t border-kiuli-gray">
      {/* Label */}
      <div className="px-3 pt-2 pb-1">
        <span className="text-[10px] font-medium uppercase tracking-wider text-[#888]">
          {label}
        </span>
      </div>
      {/* Helper */}
      <div className="px-3 pb-1">
        <span className="text-[10px] text-[#888]">{helper}</span>
      </div>

      {/* Editorial columns */}
      <div className={`mx-3 mb-2 border-l-4 ${borderColor} rounded`}>
        <div className="grid grid-cols-[1fr_36px_1fr]">
          {/* Left: iTrvl (read-only) */}
          <div
            className="bg-kiuli-ivory p-1.5 px-2.5 text-[12px] text-[#666]"
            style={{ minHeight }}
          >
            {itrvlValue || (
              <span className="italic text-[#aaa]">No iTrvl content</span>
            )}
          </div>

          {/* Center: Enhance button */}
          <div className="flex items-center justify-center">
            <button
              type="button"
              onClick={onEnhance}
              disabled={isEnhancing}
              className="flex h-6 w-6 items-center justify-center rounded transition-colors hover:bg-kiuli-ivory disabled:opacity-50"
              aria-label={`Enhance ${label.toLowerCase()}`}
            >
              <Sparkles
                className={`h-3.5 w-3.5 text-kiuli-clay ${isEnhancing ? "animate-pulse" : ""}`}
              />
            </button>
          </div>

          {/* Right: Enhanced (editable) */}
          <textarea
            value={enhancedValue}
            onChange={(e) => onEnhancedChange(e.target.value)}
            className="resize-none bg-kiuli-white p-1.5 px-2.5 text-[12px] text-kiuli-charcoal outline-none focus:ring-1 focus:ring-kiuli-teal/30"
            style={{ minHeight }}
            placeholder="Enhanced content..."
          />
        </div>
      </div>

      {/* Footer: Reviewed checkbox */}
      <div className="flex items-center gap-2 border-t border-kiuli-gray px-3 py-[5px]">
        <input
          type="checkbox"
          id={`${id}-reviewed`}
          checked={reviewed}
          onChange={(e) => onReviewedChange(e.target.checked)}
          className="h-3.5 w-3.5 rounded border-kiuli-gray accent-kiuli-teal"
        />
        <label
          htmlFor={`${id}-reviewed`}
          className={`text-[11px] ${reviewed ? "font-medium text-kiuli-green" : "text-[#888]"}`}
        >
          Reviewed
        </label>
      </div>
    </div>
  )
}
