"use client"

import { useState, useCallback } from "react"
import CoreFieldsAccordion from "@/components/core-fields-accordion"

export default function Page() {
  const [isOpen, setIsOpen] = useState(true)

  // Title
  const [titleEnhanced, setTitleEnhanced] = useState("")
  const [titleReviewed, setTitleReviewed] = useState(false)
  const [isTitleEnhancing, setIsTitleEnhancing] = useState(false)

  // Meta Title
  const [metaTitleEnhanced, setMetaTitleEnhanced] = useState(
    "Kenya Family Safari: Giraffe Manor, Lewa & the Masai Mara | Kiuli"
  )
  const [metaTitleReviewed, setMetaTitleReviewed] = useState(true)
  const [isMetaTitleEnhancing, setIsMetaTitleEnhancing] = useState(false)

  // Meta Description
  const [metaDescriptionEnhanced, setMetaDescriptionEnhanced] = useState(
    "Seven nights of extraordinary encounters across Kenya\u2019s most iconic wilderness \u2014 Giraffe Manor, Lewa House, and the Masai Mara. Crafted exclusively for families who travel with intention."
  )
  const [metaDescriptionReviewed, setMetaDescriptionReviewed] = useState(false)
  const [isMetaDescriptionEnhancing, setIsMetaDescriptionEnhancing] = useState(false)

  // Trip Types
  const [selectedTripTypes, setSelectedTripTypes] = useState<string[]>([])

  // Answer Capsule
  const [answerCapsule, setAnswerCapsule] = useState("")
  const [answerCapsuleReviewed, setAnswerCapsuleReviewed] = useState(false)

  // Focus Keyword
  const [focusKeyword, setFocusKeyword] = useState("Kenya family safari")
  const [focusKeywordReviewed, setFocusKeywordReviewed] = useState(false)

  // Simulate enhance
  const simulateEnhance = useCallback(
    (
      setLoading: (v: boolean) => void,
      setValue: (v: string) => void,
      result: string
    ) => {
      return async () => {
        setLoading(true)
        await new Promise((resolve) => setTimeout(resolve, 1200))
        setValue(result)
        setLoading(false)
      }
    },
    []
  )

  return (
    <main
      className="min-h-screen px-4 py-10 font-sans"
      style={{ background: "#F5F3EB" }}
    >
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-6 text-[18px] font-bold text-[#404040]">
          Kiuli Admin — CoreFieldsAccordion
        </h1>

        <CoreFieldsAccordion
          isOpen={isOpen}
          onToggle={() => setIsOpen((o) => !o)}
          // Title
          titleItrvl="Family-Fun in Kenya"
          titleEnhanced={titleEnhanced}
          titleReviewed={titleReviewed}
          slug="family-fun-in-kenya"
          onTitleChange={setTitleEnhanced}
          onTitleEnhance={simulateEnhance(
            setIsTitleEnhancing,
            setTitleEnhanced,
            "Kenya Family Adventure: A Luxury Safari Experience"
          )}
          onTitleReviewedChange={setTitleReviewed}
          isTitleEnhancing={isTitleEnhancing}
          // Meta Title
          metaTitleItrvl="Family-Fun in Kenya | 7-Night Luxury Safari"
          metaTitleEnhanced={metaTitleEnhanced}
          metaTitleReviewed={metaTitleReviewed}
          onMetaTitleChange={setMetaTitleEnhanced}
          onMetaTitleEnhance={simulateEnhance(
            setIsMetaTitleEnhancing,
            setMetaTitleEnhanced,
            "Kenya Family Safari: Giraffe Manor, Lewa & the Masai Mara | Kiuli"
          )}
          onMetaTitleReviewedChange={setMetaTitleReviewed}
          isMetaTitleEnhancing={isMetaTitleEnhancing}
          // Meta Description
          metaDescriptionItrvl="Experience a 7-night luxury safari through Kenya. Exclusive lodges, expert guides, and unforgettable wildlife encounters. Inquire with Kiuli today."
          metaDescriptionEnhanced={metaDescriptionEnhanced}
          metaDescriptionReviewed={metaDescriptionReviewed}
          onMetaDescriptionChange={setMetaDescriptionEnhanced}
          onMetaDescriptionEnhance={simulateEnhance(
            setIsMetaDescriptionEnhancing,
            setMetaDescriptionEnhanced,
            "Seven nights of extraordinary encounters across Kenya\u2019s most iconic wilderness \u2014 Giraffe Manor, Lewa House, and the Masai Mara. Crafted exclusively for families who travel with intention."
          )}
          onMetaDescriptionReviewedChange={setMetaDescriptionReviewed}
          isMetaDescriptionEnhancing={isMetaDescriptionEnhancing}
          // Trip Types
          selectedTripTypes={selectedTripTypes}
          onTripTypesChange={setSelectedTripTypes}
          // Answer Capsule
          answerCapsule={answerCapsule}
          answerCapsuleReviewed={answerCapsuleReviewed}
          onAnswerCapsuleChange={setAnswerCapsule}
          onAnswerCapsuleReviewedChange={setAnswerCapsuleReviewed}
          // Focus Keyword
          focusKeyword={focusKeyword}
          focusKeywordReviewed={focusKeywordReviewed}
          onFocusKeywordChange={setFocusKeyword}
          onFocusKeywordReviewedChange={setFocusKeywordReviewed}
        />
      </div>
    </main>
  )
}
