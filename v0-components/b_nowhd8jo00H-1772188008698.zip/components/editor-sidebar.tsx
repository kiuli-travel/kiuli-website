"use client"

import { CheckCircle2, Circle, AlertTriangle } from "lucide-react"

const NAV_SECTIONS = [
  { label: "Blockers", anchor: "#blockers" },
  { label: "Hero", anchor: "#hero" },
  { label: "Core Fields", anchor: "#core" },
  { label: "Days", anchor: "#days" },
  { label: "Investment", anchor: "#investment" },
  { label: "FAQ", anchor: "#faq" },
  { label: "SEO & Metadata", anchor: "#seo" },
]

interface ChecklistItem {
  label: string
  status: "done" | "warning" | "missing"
}

const CHECKLIST: ChecklistItem[] = [
  { label: "Title", status: "missing" },
  { label: "Meta Title", status: "done" },
  { label: "Meta Description", status: "warning" },
  { label: "Hero Image", status: "done" },
  { label: "Trip Types", status: "missing" },
  { label: "Day Descriptions", status: "missing" },
  { label: "Investment Levels", status: "missing" },
  { label: "FAQ Content", status: "warning" },
  { label: "Focus Keyword", status: "missing" },
  { label: "Slug", status: "done" },
]

function StatusIcon({ status }: { status: ChecklistItem["status"] }) {
  if (status === "done") return <CheckCircle2 size={15} className="text-emerald-600 flex-shrink-0" />
  if (status === "warning") return <AlertTriangle size={15} className="text-amber-500 flex-shrink-0" />
  return <Circle size={15} className="text-[#DADADA] flex-shrink-0" />
}

export default function EditorSidebar() {
  const doneCount = CHECKLIST.filter((c) => c.status === "done").length
  const totalCount = CHECKLIST.length
  const pct = Math.round((doneCount / totalCount) * 100)

  return (
    <div className="flex flex-col gap-6">
      {/* Quick Nav */}
      <div>
        <h3 className="text-xs font-semibold uppercase tracking-wider text-[#6B6B6B] mb-3">
          Quick Nav
        </h3>
        <nav className="flex flex-col gap-0.5">
          {NAV_SECTIONS.map((s) => (
            <a
              key={s.anchor}
              href={s.anchor}
              className="text-sm py-1.5 px-2 rounded transition-colors hover:bg-[#F5F3EB] text-[#404040]"
            >
              {s.label}
            </a>
          ))}
        </nav>
      </div>

      {/* Divider */}
      <div style={{ height: 1, background: "#DADADA" }} />

      {/* Publish Checklist */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-[#6B6B6B]">
            Publish Checklist
          </h3>
          <span className="text-xs font-semibold text-[#486A6A]">{pct}%</span>
        </div>

        {/* Progress bar */}
        <div
          className="rounded-full overflow-hidden mb-4"
          style={{ height: 4, background: "#DADADA" }}
        >
          <div
            className="h-full rounded-full transition-all"
            style={{ width: `${pct}%`, background: "#486A6A" }}
          />
        </div>

        <ul className="flex flex-col gap-2">
          {CHECKLIST.map((item) => (
            <li key={item.label} className="flex items-center gap-2">
              <StatusIcon status={item.status} />
              <span
                className={`text-sm ${item.status === "done" ? "text-[#6B6B6B] line-through" : "text-[#404040]"}`}
              >
                {item.label}
              </span>
            </li>
          ))}
        </ul>
      </div>

      {/* Divider */}
      <div style={{ height: 1, background: "#DADADA" }} />

      {/* Not Ready */}
      <div className="flex flex-col gap-3">
        <div
          className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium"
          style={{ background: "#FEF2F2", color: "#DC2626" }}
        >
          <AlertTriangle size={14} />
          Not ready to publish
        </div>
        <button
          disabled
          className="w-full rounded-md py-2 text-sm font-semibold text-white disabled:opacity-40"
          style={{ background: "#486A6A" }}
        >
          Publish Itinerary
        </button>
      </div>
    </div>
  )
}
