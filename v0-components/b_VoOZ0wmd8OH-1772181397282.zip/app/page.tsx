"use client"

import { useState, useCallback } from "react"
import { ImageStrip } from "@/components/image-strip"

interface StripImage {
  id: string
  url: string
  alt: string
}

function useImageStripState(initialCount: number, initialReviewed: boolean) {
  const [images, setImages] = useState<StripImage[]>(() =>
    Array.from({ length: initialCount }, (_, i) => ({
      id: `img-${Date.now()}-${i}`,
      url: "",
      alt: `Placeholder ${i + 1}`,
    }))
  )
  const [reviewed, setReviewed] = useState(initialReviewed)

  const addImage = useCallback(() => {
    setImages((prev) => [
      ...prev,
      {
        id: `img-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        url: "",
        alt: `Placeholder ${prev.length + 1}`,
      },
    ])
  }, [])

  const removeImage = useCallback((id: string) => {
    setImages((prev) => prev.filter((img) => img.id !== id))
  }, [])

  return { images, reviewed, setReviewed, addImage, removeImage }
}

export default function Page() {
  const strip1 = useImageStripState(3, false)
  const strip2 = useImageStripState(5, true)
  const strip3 = useImageStripState(0, false)

  const demos = [
    { label: "3 images, not reviewed", state: strip1 },
    { label: "5 images, reviewed", state: strip2 },
    { label: "0 images — add button only", state: strip3 },
  ]

  return (
    <main
      className="min-h-screen font-sans"
      style={{ backgroundColor: "#F5F3EB" }}
    >
      <div className="mx-auto max-w-2xl px-6 py-12">
        <h1
          className="mb-8 text-balance font-sans"
          style={{
            fontSize: "20px",
            fontWeight: 600,
            color: "#404040",
          }}
        >
          Kiuli Admin — ImageStrip Component
        </h1>

        <div className="flex flex-col gap-4">
          {demos.map(({ label, state }) => (
            <div key={label}>
              <p
                className="mb-1.5 font-sans"
                style={{
                  fontSize: "12px",
                  fontWeight: 500,
                  color: "#666",
                }}
              >
                {label}
              </p>
              <div
                style={{
                  border: "1px solid #DADADA",
                  borderRadius: "6px",
                  overflow: "hidden",
                  backgroundColor: "#FFFFFF",
                }}
              >
                <ImageStrip
                  images={state.images}
                  imagesReviewed={state.reviewed}
                  onImagesReviewedChange={state.setReviewed}
                  onAddImage={state.addImage}
                  onRemoveImage={state.removeImage}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
