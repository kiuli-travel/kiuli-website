"use client"

import EditorSidebar from "@/components/editor-sidebar"

// ─── Demo Data ───────────────────────────────────────────────────────────────

const notReadyNav = [
  { id: "blockers", label: "Blockers", reviewed: 0, total: 0, isBlocker: true, blockerCount: 2 },
  { id: "hero", label: "Hero Image", reviewed: 0, total: 1 },
  { id: "core", label: "Core Fields", reviewed: 1, total: 6 },
  {
    id: "days",
    label: "Days",
    reviewed: 0,
    total: 45,
    subItems: [
      { id: "day-1", label: "Day 1", reviewed: 0, total: 12 },
      { id: "day-2", label: "Day 2", reviewed: 0, total: 11 },
      { id: "day-5", label: "Day 5", reviewed: 0, total: 12 },
      { id: "day-8", label: "Day 8", reviewed: 0, total: 10 },
    ],
  },
  { id: "investment", label: "Investment", reviewed: 0, total: 1 },
  { id: "faqs", label: "FAQs", reviewed: 1, total: 7 },
  { id: "seo", label: "SEO & Metadata", reviewed: 0, total: 3 },
]

const notReadyChecklist = [
  { id: "core", label: "Core Fields", reviewed: 1, total: 6 },
  { id: "day-titles", label: "Day Titles", reviewed: 0, total: 4 },
  { id: "segments", label: "Segments", reviewed: 0, total: 45 },
  { id: "faqs", label: "FAQs", reviewed: 1, total: 7 },
  { id: "investment", label: "Investment", reviewed: 0, total: 1 },
  { id: "seo", label: "SEO & Metadata", reviewed: 0, total: 3 },
  { id: "pipeline", label: "Pipeline Checks", reviewed: 2, total: 3 },
]

const readyNav = [
  { id: "blockers", label: "Blockers", reviewed: 0, total: 0, isBlocker: true, blockerCount: 0 },
  { id: "hero", label: "Hero Image", reviewed: 1, total: 1 },
  { id: "core", label: "Core Fields", reviewed: 6, total: 6 },
  {
    id: "days",
    label: "Days",
    reviewed: 45,
    total: 45,
    subItems: [
      { id: "day-1", label: "Day 1", reviewed: 12, total: 12 },
      { id: "day-2", label: "Day 2", reviewed: 11, total: 11 },
      { id: "day-5", label: "Day 5", reviewed: 12, total: 12 },
      { id: "day-8", label: "Day 8", reviewed: 10, total: 10 },
    ],
  },
  { id: "investment", label: "Investment", reviewed: 1, total: 1 },
  { id: "faqs", label: "FAQs", reviewed: 7, total: 7 },
  { id: "seo", label: "SEO & Metadata", reviewed: 3, total: 3 },
]

const readyChecklist = [
  { id: "core", label: "Core Fields", reviewed: 6, total: 6 },
  { id: "day-titles", label: "Day Titles", reviewed: 4, total: 4 },
  { id: "segments", label: "Segments", reviewed: 45, total: 45 },
  { id: "faqs", label: "FAQs", reviewed: 7, total: 7 },
  { id: "investment", label: "Investment", reviewed: 1, total: 1 },
  { id: "seo", label: "SEO & Metadata", reviewed: 3, total: 3 },
  { id: "pipeline", label: "Pipeline Checks", reviewed: 3, total: 3 },
]

// ─── Placeholder content for left column ─────────────────────────────────────

function PlaceholderContent() {
  const sections = [
    "Hero Image",
    "Core Fields",
    "Day 1 — Arrival & Welcome",
    "Day 2 — Safari & Exploration",
    "Day 5 — Cultural Immersion",
    "Day 8 — Departure",
    "Investment",
    "FAQs",
    "SEO & Metadata",
  ]

  return (
    <div className="flex flex-col gap-4">
      <div
        className="rounded-lg px-5 py-4"
        style={{ backgroundColor: "#FFFFFF", border: "1px solid #DADADA" }}
      >
        <p style={{ fontSize: "13px", fontWeight: 500, color: "#888" }}>
          Main editorial content scrolls here
        </p>
      </div>
      {sections.map((name) => (
        <div
          key={name}
          className="rounded-lg px-5 py-8"
          style={{ backgroundColor: "#FFFFFF", border: "1px solid #DADADA" }}
        >
          <p style={{ fontSize: "14px", fontWeight: 600, color: "#404040" }}>{name}</p>
          <div
            className="mt-3 rounded"
            style={{ height: "48px", backgroundColor: "#F5F3EB" }}
          />
          <div
            className="mt-2 rounded"
            style={{ height: "32px", backgroundColor: "#F5F3EB", width: "70%" }}
          />
        </div>
      ))}
    </div>
  )
}

// ─── Page ────────────────────────────────────────────────────────────────────

export default function Page() {
  const noop = () => {}

  return (
    <div
      className="min-h-screen font-sans"
      style={{ backgroundColor: "#F5F3EB" }}
    >
      {/* Page header */}
      <header
        className="border-b px-8 py-4"
        style={{ backgroundColor: "#FFFFFF", borderColor: "#DADADA" }}
      >
        <h1 style={{ fontSize: "16px", fontWeight: 700, color: "#404040" }}>
          Kiuli Admin — EditorSidebar
        </h1>
      </header>

      {/* Two sidebar states side by side */}
      <main className="mx-auto flex max-w-6xl flex-col gap-12 px-8 py-10">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
          {/* Not ready column */}
          <div className="flex flex-col gap-4">
            <span
              className="inline-block rounded-full px-3 py-1 self-start"
              style={{
                fontSize: "11px",
                fontWeight: 600,
                backgroundColor: "#FEE2E2",
                color: "#DC2626",
              }}
            >
              Not ready to publish
            </span>
            <div className="flex gap-5">
              <div className="flex-1 min-w-0">
                <PlaceholderContent />
              </div>
              <div className="shrink-0">
                <EditorSidebar
                  navSections={notReadyNav}
                  checklistSections={notReadyChecklist}
                  onNavigate={noop}
                  onPublish={noop}
                  canPublish={false}
                />
              </div>
            </div>
          </div>

          {/* Ready column */}
          <div className="flex flex-col gap-4">
            <span
              className="inline-block rounded-full px-3 py-1 self-start"
              style={{
                fontSize: "11px",
                fontWeight: 600,
                backgroundColor: "#DCFCE7",
                color: "#16A34A",
              }}
            >
              Ready to publish
            </span>
            <div className="flex gap-5">
              <div className="flex-1 min-w-0">
                <PlaceholderContent />
              </div>
              <div className="shrink-0">
                <EditorSidebar
                  navSections={readyNav}
                  checklistSections={readyChecklist}
                  onNavigate={noop}
                  onPublish={noop}
                  canPublish={true}
                />
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
